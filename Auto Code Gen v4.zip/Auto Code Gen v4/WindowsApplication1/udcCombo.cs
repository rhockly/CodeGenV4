using System.Windows;
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Data;

    public partial class udcCombo : System.Windows.Forms.ComboBox
    {
        private ArrayList moArrayList;
    
        public udcCombo()
        {
            InitializeComponent();
        }

        public udcCombo(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
        }
 
    public void ucAddItem(string Id,string  Data)
    {
        cListItem oListItem;
        this.DataSource = null;
        if (moArrayList == null)
        {
            moArrayList = new ArrayList();
        }
        oListItem = new cListItem(Id, Data);
        moArrayList.Add(oListItem);
    }

    public void ucClear()
    {
        moArrayList = null;
        this.DataSource = null;
        this.Items.Clear();
    }

    public void ucRender()
    {
        this.Items.Clear();
        this.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.DataSource = moArrayList;
        this.DisplayMember = "Name";
        this.ValueMember = "ID";
    }

    public void ucSetId(string pId)
    {
  
        int nCount  = 0;
        if (moArrayList == null)
        {
            return;
        }
        if (moArrayList.Count==0)
        {
            return;
        }
        foreach (cListItem oListItem in moArrayList)
        {
            if (oListItem.ID == pId)
            {
                break;
            }
            nCount += 1;
        }
        if (nCount < this.Items.Count)
        {
            this.SelectedIndex = nCount;
        }
    }

    public string ucGetId()
    {
        cListItem oListItem;
        
        if (this.SelectedIndex != -1)
        {
            oListItem =(cListItem) moArrayList[this.SelectedIndex];
            return oListItem.ID;
        }
        return null;
    }

        public void ucDisplayDataTable(DataTable DataTableX)
        {
            
            
            int IndexOfTheId = 0;
            int IndexOfTheDisplayData = -1;
            int Counter = -1;
            

            foreach (DataColumn DataColumn in DataTableX.Columns)
            {
                Counter += 1;

                if (DataColumn.ColumnName.Length > 2)
                {
                    if (DataColumn.ColumnName.Substring(0, 2).ToLower() == "id")
                    {
                        IndexOfTheId = Counter;

                    }
                }

                if (DataColumn.ColumnName.Length > 2)
                {
                    if (DataColumn.ColumnName.ToString().ToLower().IndexOf("name") != -1)
                    {
                        IndexOfTheDisplayData = Counter;

                    }
                }

            }
            string Id = "";
            string Data = "";
            foreach (DataRow Myrow in DataTableX.Rows)
            {
                Id = Myrow.ItemArray[IndexOfTheId].ToString();
                if (IndexOfTheDisplayData==-1)
                {
                    Data = Id.ToString()+"-no data";
                }
                else
                {
                    Data = Myrow.ItemArray[IndexOfTheDisplayData].ToString();
                }
               
                this.ucAddItem(Id, Data);
            }
            this.ucRender();
        }
}

public class cListItem
{
    string _ID ;
    string _Name ;

    public cListItem(string ID, string Name)
    {
        this._ID = ID;
        this._Name = Name;
    }

    public string ID
    {
        get
        {
            return _ID;
        }  
    }

    public string Name
    {
        get
        {
            return _Name;
        }  
    }

}

