using System;
using System.Collections.Generic;
using System.Text;

namespace RH
{
  
   public class TempControl
   {
       public TempControl(MDFieldDef xMDFieldDef)
       {
           MDFieldDef = xMDFieldDef;
       }
       public string ControlName;
       public string Declaration;
       public string Body;
       public string VarDec;
       public MDFieldDef MDFieldDef;
    }
}
