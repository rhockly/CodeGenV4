using System.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using System.Data.Odbc;
using System.Data.Common;


namespace RH
{
    public class MDFKentry
    {
        public string table
        {
            get { return fkTable; }
            set { fkTable = value; }
        } private string fkTable;

        public string field
        {
            get { return fkField; }
            set { fkField = value; }
        } private string fkField;

        public string exposedName
        {
            get { return _exposedName; }
            set { _exposedName = value; }
        }private string _exposedName;

        public string privateType
        {
            get { return _type; }
            set { _type = value; }
        } private string _type;

    }
}
