using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using Microsoft.Win32;
namespace RH
{
    public partial class frmMain : Form
    {
        MDDataBaseDef _metadata = new MDDataBaseDef();

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            toolTip1.AutoPopDelay = 5000;
            toolTip1.InitialDelay = 1000;
            toolTip1.ReshowDelay = 500;
            toolTip1.ShowAlways = true;

            txtTemplateFolder.Text = GetSetting("txtTemplateFolder");
            txtOutputFolder.Text = GetSetting("txtOutputFolder");
            txtClassNamePrefix.Text = GetSetting("txtClassNamePrefix");
            txtFormNamePrefix.Text = GetSetting("txtFormNamePrefix");
            toolTip1.SetToolTip(txtTemplateFolder, txtTemplateFolder.Text);
            toolTip1.SetToolTip(txtOutputFolder, txtOutputFolder.Text);
        }

        private string GetSetting(string ControlName)
        {
            RegistryKey keyLocalMachine = Registry.LocalMachine;
            RegistryKey keySoftware = keyLocalMachine.CreateSubKey("Software");
            RegistryKey keyApp = keySoftware.CreateSubKey("AutoCodeGen");

            string dt = "";
            dt = (String)keyApp.GetValue(ControlName);
            return dt;
        }

        private void SaveSetting(string ControlName, string NewValue)
        {
            RegistryKey keyLocalMachine = Registry.LocalMachine;
            RegistryKey keySoftware = keyLocalMachine.OpenSubKey("Software");
            RegistryKey keyApp = keySoftware.OpenSubKey("AutoCodeGen", true);
            keyApp.SetValue(ControlName, NewValue);
        }

        private void btnFindTemplates_Click(object sender, EventArgs e)
        {

            cBrowseFolder oBrowserFolder = new cBrowseFolder();
            if (oBrowserFolder.ShowDialog() == DialogResult.OK)
            {
                txtTemplateFolder.Text = oBrowserFolder.Path + "\\";
                toolTip1.SetToolTip(txtTemplateFolder, txtTemplateFolder.Text);
                SaveSetting("txtTemplateFolder", txtTemplateFolder.Text);
            }
        }

        private void btnFindOutputFolder_Click(object sender, EventArgs e)
        {
            cBrowseFolder oBrowserFolder = new cBrowseFolder();
            if (oBrowserFolder.ShowDialog() == DialogResult.OK)
            {
                txtOutputFolder.Text = oBrowserFolder.Path + "\\";
                SaveSetting("txtOutputFolder", txtOutputFolder.Text);
                toolTip1.SetToolTip(txtOutputFolder, txtOutputFolder.Text);
            }
        }

        private void btnMakeCode_Click(object sender, EventArgs e)
        {

        }

        private void btnGetDbStructure_Click(object sender, EventArgs e)
        {


            string displayText = "";
            int KeyCounter = 0;

            _metadata.Clear();
            _metadata.ExtractTables();

            tablesTree.Nodes.Clear();


            //Add the fields

            foreach (MDTableDef table in _metadata.tableList)
            {
                TreeNode node = tablesTree.Nodes.Add(table.name, table.name);
                node.Checked = (table.markedForGeneration);
                foreach (MDFieldDef def in table.fields)
                {
                    displayText = def.name + " - " + def.fieldType;
                    if (def.size != 0)
                    {
                        displayText += "(" + def.size + ")";
                    }
                    if (def.isForeignKey)
                    {
                        displayText += "     (relates to table - " + def.relatesToTable + ")";
                    }

                    KeyCounter += 1;
                    TreeNode leafNode = node.Nodes.Add(KeyCounter.ToString(), displayText);


                    if (def.isTimeStamp)
                    {
                        // Timestamp
                        leafNode.ImageIndex = (int)eTreeImages.eTreeImageTs;
                        leafNode.SelectedImageIndex = (int)eTreeImages.eTreeImageTsSel;
                    }

                    if (def.isIdentity)
                    {
                        // id
                        leafNode.ImageIndex = (int)eTreeImages.eTreeImageId;
                        leafNode.SelectedImageIndex = (int)eTreeImages.eTreeImageIdSel;
                    }

                    if (def.isForeignKey)
                    {
                        //FK
                        leafNode.ImageIndex = (int)eTreeImages.eTreeImageFk;
                        leafNode.SelectedImageIndex = (int)eTreeImages.eTreeImageFkSel;
                    }


                    if (table.markedForGeneration)
                        node.Expand();
                }
            }

            if (_metadata.tableList.Count > 0)
            {
                btnMake.Enabled = true;
                btnMake.Enabled = true;
            }

        }

        private void txtClassNamePrefix_TextChanged(object sender, EventArgs e)
        {
            SaveSetting("txtClassNamePrefix", txtClassNamePrefix.Text);
        }

        private void txtFormNamePrefix_TextChanged(object sender, EventArgs e)
        {
            SaveSetting("txtFormNamePrefix", txtFormNamePrefix.Text);
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            //Make Classes
            ClassGenerator4 ClassGen = new ClassGenerator4(txtTemplateFolder.Text, txtOutputFolder.Text);
            foreach (MDTableDef table in _metadata.tableList)
            {
                MDTableDef Passtable = table;
                ClassGen.MakeClassAndSqlForTable(ref Passtable, txtClassNamePrefix.Text, txtOutputFolder.Text);
            }

            //Make Fe
            ClassGenerator4FE ClassGenFE = new ClassGenerator4FE(txtTemplateFolder.Text, txtOutputFolder.Text);
           
            ClassGenFE.MakeUiForTables(ref _metadata,txtFormNamePrefix.Text, txtOutputFolder.Text);
     
            
            btnMake.Enabled = false;
            this.Close();
        }

        private void btnShowEntity_Click(object sender, EventArgs e)
        {

            //frmSelectSupplier frm = new frmSelectSupplier();
            //frm.PopulateGridAndShowForm();

            frmSelectBaseProduct frm = new frmSelectBaseProduct();
            frm.PopulateGridAndShowForm();
        }


     


    }


}

enum eTreeImages
{
    eTreeImageBlank = 0,
    eTreeImageId = 1,
    eTreeImageTs = 2,
    eTreeImageSel = 3,
    eTreeImageIdSel = 4,
    eTreeImageTsSel = 5,
    eTreeImageFk = 6,
    eTreeImageFkSel = 7
};

