
using System.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using System.Data.Odbc;
using System.Data.Common;

namespace RH
{
    public class MDTableDef
    {
        public string name;
        public string IdFieldName;
        public string ForeignIdName="";
        public List<MDFieldDef> fields;
        public bool markedForGeneration;
        public string ClassName;
        public string ClassNameWithPrefix;

        public MDTableDef()
        {
            fields = new List<MDFieldDef>();
           
        }

        public MDFieldDef FindField(string fieldName)
        {
            foreach (MDFieldDef f in fields)
                if (f.name == fieldName)
                    return f;
            return null;
        }

        public override bool Equals(object obj)
        {
            MDTableDef test = obj as MDTableDef;
            if (test == null)
            {
                return false;
            }

            if (test.name==name)
            {
                return true;
            }
            else
	        {
                return false;
	        }
           
        }
       
    }
  

}
