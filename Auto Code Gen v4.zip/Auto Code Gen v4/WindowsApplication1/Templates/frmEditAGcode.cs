using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmEdit
{
    private int _id = 0;
    private Object _ClassName;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;
//[POPULATELOOKUPS]
        if (_id != 0)
        {
            _ClassName = new Object();
            //[Pop]_ClassName.Populate(_id);
//[POPULATECONTROLS]
        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _ClassName = new Object();
            //[ts]ClassName.Ts = DateTime.Now;
        }

//[SAVECONTROLS]

        //[eRes] = _ClassName.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
//[ValidateCodeHandlers]

}

