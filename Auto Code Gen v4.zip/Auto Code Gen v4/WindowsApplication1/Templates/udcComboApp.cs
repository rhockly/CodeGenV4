using System.Windows;
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Data;
public partial class udcComboApp : udcCombo
    {
      
    
    public udcComboApp()
    {
        InitializeComponent();
    }

    public udcComboApp(IContainer container)
    {
        container.Add(this);
        InitializeComponent();
    }
    //[Block]
    //public void ucDisplay[ClassName]s()
    //{
    //    [ClassNameWithPrefix]s [ClassName]s = new [ClassNameWithPrefix]s();
    //    this.ucDisplayDataTable([ClassName]s.PopulateForUiList());
    //}
    //[EndBlock]
}



