using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;

namespace RH
{
    public class ClassGenerator4FE
    {

        #region private constants
        private const string SELECT_TEMPLATE = "frmSelect.cs";
        private const string SELECT_DESIGN_TEMPLATE = "frmSelect.Designer.cs";

        private const string COMBO_TEMPLATE = "udcComboApp.cs";
        private const string COMBO_DESIGN_TEMPLATE = "udcComboApp.Designer.cs";

        private const string EDIT_TEMPLATE = "frmEdit.cs";
        private const string EDIT_TEMPLATE_EXTRA = "frmEditAGcode.cs";
        private const string EDIT_DESIGN_TEMPLATE = "frmEdit.Designer.cs";
        private const string QUOTE = "\"";
        private const string NEWLINE = "\r\n";
        private const string TAB1 = "\t";
        private const string TAB2 = "\t\t";

        #endregion

        #region private Variables

        private int _Xpos;
        private int _Ypos;
        private string _TemplatePath;
        private string _OutputPath;
        private Hashtable _htbTemplatesDesigner;
        #endregion



        #region Constructor

        public ClassGenerator4FE(string p_sTemplatePath, string p_sOutputPath)
        {
            _TemplatePath = p_sTemplatePath;
            _OutputPath = p_sOutputPath;
            GetTemplate(SELECT_DESIGN_TEMPLATE);
            GetTemplate(SELECT_TEMPLATE);
            GetTemplate(EDIT_DESIGN_TEMPLATE);
            GetTemplate(EDIT_TEMPLATE);
            GetTemplate(EDIT_TEMPLATE_EXTRA);
            GetTemplate(COMBO_TEMPLATE);
            GetTemplate(COMBO_DESIGN_TEMPLATE);
        }

        #endregion

        public void MakeUiForTables(ref MDDataBaseDef metadata, string FormNamePrefix, string OutputPath)
        {
            //Make a udcComboApp for all the tables
            string ComboTemplate = _htbTemplatesDesigner[COMBO_TEMPLATE].ToString();
            string All = ComboTemplate.Substring(0, ComboTemplate.IndexOf("//[Block]") - 1);
            int StartPos = ComboTemplate.IndexOf("//[Block]") + 9;
            int EndPos = ComboTemplate.IndexOf("//[EndBlock]") - 1;
            string HoldReplaceSection = ComboTemplate.Substring(StartPos, EndPos - StartPos);
            string LastSection = "}";
            string newLines = "";

            foreach (MDTableDef table in metadata.tableList)
            {
                newLines = HoldReplaceSection;

                newLines = newLines.Replace("[ClassName]", table.ClassName);
                newLines = newLines.Replace("[ClassNameWithPrefix]", table.ClassNameWithPrefix);
                newLines = newLines.Replace("//", "");
                All += newLines;
            }
            All += LastSection;
            All = All.Replace("udcComboApp", "udcComboForUI");

            SaveForm(OutputPath + "udcComboForUI.cs", All);

            string ComboDesignTemplate = _htbTemplatesDesigner[COMBO_DESIGN_TEMPLATE].ToString();
            ComboDesignTemplate = ComboDesignTemplate.Replace("udcComboApp", "udcComboForUI");
            SaveForm(OutputPath + "udcComboForUI.Designer.cs", ComboDesignTemplate);




            //Make EDIT the forms
            foreach (MDTableDef table in metadata.tableList)
            {
                MDTableDef Passtable = table;
                MakeEditFormForTable(ref Passtable, FormNamePrefix, OutputPath);
            }

            //Make SELECT forms
            foreach (MDTableDef table in metadata.tableList)
            {
                MDTableDef Passtable = table;
                MakeSelectFormForTable(ref Passtable, FormNamePrefix, OutputPath);
            }
        }

        private void MakeSelectFormForTable(ref MDTableDef Table, string FormNamePrefix, string OutputPath)
        {
            
            string SelectDesignTemplate = _htbTemplatesDesigner[SELECT_DESIGN_TEMPLATE].ToString();
            string SelectTemplate = _htbTemplatesDesigner[SELECT_TEMPLATE].ToString();

            String All = SelectDesignTemplate;
            All = All.Replace("frmSelect", FormNamePrefix + "Select" + Table.ClassName);
            
            string FormNameDesign = FormNamePrefix +"Select" + Table.ClassName + ".Designer.cs";
            SaveForm(OutputPath + FormNameDesign, All);

            
            All = SelectTemplate;
            All = All.Replace("frmSelect", FormNamePrefix + "Select" + Table.ClassName);
            All = All.Replace("[CLASSNAME]", Table.ClassName);
            All = All.Replace("//", "");

            string FormName = FormNamePrefix + "Select" + Table.ClassName + ".cs";
            SaveForm(OutputPath + FormName, All);
        }

        private void MakeEditFormForTable(ref MDTableDef Table, string FormNamePrefix, string OutputPath)
        {

            int ControlCount = 0;
            Hashtable htbTempControls = new Hashtable();

            foreach (MDFieldDef FieldDef in Table.fields)
            {

                if (FieldDef.isForeignKey)
                {
                    MakeControl(ControlType.udcComboForUI, FieldDef, ref ControlCount, ref htbTempControls);
                }
                else if (!FieldDef.isIdentity & !FieldDef.isTimeStamp)
                {
                    ControlType PassControlType = ControlType.Textbox;
                    if (FieldDef.fieldType.ToLower() == "bit")
                    {
                		 PassControlType = ControlType.CheckBox;
                    }
                    MakeControl(PassControlType, FieldDef, ref ControlCount, ref htbTempControls);
                }

            }

            //Create the code to add
            string EditTemplateExtra = _htbTemplatesDesigner[EDIT_TEMPLATE_EXTRA].ToString();
            string EditTemplate = _htbTemplatesDesigner[EDIT_TEMPLATE].ToString();
            string EditDesignTemplate = _htbTemplatesDesigner[EDIT_DESIGN_TEMPLATE].ToString();
            string Declarations = "";
            string Bodys = "";
            string VarDecs = "";
            string AddControls = "";
            foreach (TempControl tc in htbTempControls.Values)
            {
                Declarations += tc.Declaration;
                Bodys += tc.Body;
                VarDecs += tc.VarDec;
                AddControls += "this.Controls.Add(this." + tc.ControlName + ");" + NEWLINE;
            }

            //Add the code to the template copy
            string FirstSection = EditDesignTemplate.Substring(0, EditDesignTemplate.IndexOf("this.SuspendLayout();") - 1);
            string LastSection = EditDesignTemplate.Substring(EditDesignTemplate.IndexOf("this.SuspendLayout();") + 22);
            string All;

            FirstSection += Declarations + NEWLINE;
            FirstSection += TAB2 + "this.SuspendLayout();" + NEWLINE;
            FirstSection += Bodys;

            All = FirstSection + LastSection;

            All = All.Substring(0, All.LastIndexOf("}") - 1) + NEWLINE + VarDecs + "}";


            string ReplaceText = "this.Name = " + QUOTE + "frmEdit" + QUOTE + ";";
            All = All.Replace(ReplaceText, AddControls + ReplaceText);

            string xxx = "this.ResumeLayout(false);";
            string FormCaption = "this.Text = " + QUOTE + Table.ClassName + QUOTE + ";" + NEWLINE + xxx;
            All = All.Replace(xxx, FormCaption);
            
            All = All.Replace("frmEdit", FormNamePrefix + Table.ClassName);

            string FormNameDesign = FormNamePrefix + Table.ClassName + ".Designer.cs";
            SaveForm(OutputPath + FormNameDesign, All);

            string FormName = FormNamePrefix + Table.ClassName + ".cs";
            All = EditTemplate;
            All = All.Replace("frmEdit", FormNamePrefix + Table.ClassName);
            SaveForm(OutputPath + FormName, All);

            All = EditTemplateExtra;
            All = All.Replace("frmEdit", FormNamePrefix + Table.ClassName);
            string FormNamePartial = FormNamePrefix + Table.ClassName + "AGcode.cs";
            string ValidateCodeHandlers = "";
            string PopulateCode = "";
            string PopulateLookups = "";
            string SaveCode = "";
            string ConvertorCode = "";
            foreach (TempControl tc in htbTempControls.Values)
            {
                if (tc.ControlName.Substring(0, 3) == "txt")
                {
                    switch (tc.MDFieldDef.fieldType.ToLower())
                    {
                        case  "int":
                            ConvertorCode="Convert.ToInt32(";
                            break;

                        case "decimal":
                            ConvertorCode="Convert.ToDecimal(";
                            break;

                        case "datetime":
                                 ConvertorCode = "Convert.ToDateTime(";
                            break;


                        default:
                            ConvertorCode = "";
                            break;
                    }
                    PopulateCode += TAB1 + TAB2 + tc.ControlName + ".Text = _" + Table.ClassName + "." + tc.ControlName.Substring(3) + ".ToString();" + NEWLINE;
                    if (ConvertorCode=="")
                    {
                          SaveCode += TAB1 + TAB2 + "_" + Table.ClassName + "." + tc.ControlName.Substring(3) + " = " + tc.ControlName + ".Text;" + NEWLINE;

                      }
                      else
                      {
                          SaveCode += TAB1 + TAB2 + "_" + Table.ClassName + "." + tc.ControlName.Substring(3) + " = "+ConvertorCode + tc.ControlName + ".Text);" + NEWLINE;

                      }
                   
                    ValidateCodeHandlers += TAB1 + "private void " + tc.ControlName + "_TextChanged(object sender, EventArgs e)" + NEWLINE;
                    ValidateCodeHandlers += TAB1 + "{" + NEWLINE;
                    ValidateCodeHandlers += TAB2 + "ValidateControls();" + NEWLINE;
                    ValidateCodeHandlers += TAB1 + "}" + NEWLINE;
                }


                if (tc.ControlName.Length > 13)
                {
                    if (tc.ControlName.Substring(0, 13) == "udcComboForUI")
                    {
                        PopulateLookups += TAB1 + TAB2 + tc.ControlName + ".ucDisplay" + tc.ControlName.Substring(13, tc.ControlName.Length - 15) + "s();" + NEWLINE;
                        PopulateCode += TAB1 + TAB2 + tc.ControlName + ".ucSetId(_" + Table.ClassName + "." + tc.ControlName.Substring(13) + ".ToString());" + NEWLINE;

                        SaveCode += TAB1 + TAB2 + "_" + Table.ClassName + "." + tc.ControlName.Substring(13) + " = System.Convert.ToInt32( " + tc.ControlName + ".ucGetId());" + NEWLINE;
                        ValidateCodeHandlers += TAB1 + "private void " + tc.ControlName + "_SelectedValueChanged(object sender, EventArgs e)" + NEWLINE;
                        ValidateCodeHandlers += TAB1 + "{" + NEWLINE;
                        ValidateCodeHandlers += TAB2 + "ValidateControls();" + NEWLINE;
                        ValidateCodeHandlers += TAB1 + "}" + NEWLINE;
                    }
                }

                if (tc.ControlName.Substring(0, 3) == "chk")
                {
    
                    PopulateCode += TAB1 + TAB2 + tc.ControlName + ".Checked = _" + Table.ClassName + "." + tc.ControlName.Substring(3)+ ";"+  NEWLINE;
               
                    SaveCode += TAB1 + TAB2 + "_" + Table.ClassName + "." + tc.ControlName.Substring(3) + " = " + tc.ControlName + ".Checked;" + NEWLINE;
                    ValidateCodeHandlers += TAB1 + "private void " + tc.ControlName + "_CheckedChanged(object sender, EventArgs e)" + NEWLINE;
                    ValidateCodeHandlers += TAB1 + "{" + NEWLINE;
                    ValidateCodeHandlers += TAB2 + "ValidateControls();" + NEWLINE;
                    ValidateCodeHandlers += TAB1 + "}" + NEWLINE;
                }
            }
            //_ClassName.ts = DateTime.Now;

            All = All.Replace("//[ts]", "_");
            All = All.Replace("//[eRes]", "eRes");
            All = All.Replace("//[Pop]", "");
            All = All.Replace("//[ValidateCodeHandlers]", ValidateCodeHandlers);
            All = All.Replace("//[SAVECONTROLS]", SaveCode);
            All = All.Replace("//[POPULATECONTROLS]", PopulateCode);

            All = All.Replace("//[POPULATELOOKUPS]", PopulateLookups);
            All = All.Replace("Object", Table.ClassNameWithPrefix);
            All = All.Replace("ClassName", Table.ClassName);
            SaveForm(OutputPath + FormNamePartial, All);
        }

        private string LoadTemplate(string p_sFullPath)
        {
            StreamReader Template = new StreamReader(p_sFullPath);
            string ReadData;
            ReadData = Template.ReadToEnd();
            Template.Close();
            return ReadData;
        }

        private string GetTemplate(string p_sFilename)
        {
            if (_htbTemplatesDesigner == null)
            {
                _htbTemplatesDesigner = new Hashtable();
            }

            if (_htbTemplatesDesigner.ContainsKey(p_sFilename))
            {
                return _htbTemplatesDesigner[p_sFilename].ToString();
            }

            else
            {
                _htbTemplatesDesigner.Add(p_sFilename, LoadTemplate(_TemplatePath + p_sFilename));
                return _htbTemplatesDesigner[p_sFilename].ToString();
            }
        }

        private void SaveForm(string p_sFullPath, string p_sContent)
        {


            StringWriter newCode = new StringWriter();
            StreamWriter St = new StreamWriter(p_sFullPath, false);
            St.Write(p_sContent);

            St.Close();


        }

        private void MakeControl(ControlType MakeControlType, MDFieldDef FieldDef, ref int ControlCount, ref Hashtable htbTempControls)
        {

            string Body = "";
            string Declaration = "";
            
            TempControl tControl = new TempControl(FieldDef);

            switch (MakeControlType)
            {
                case ControlType.Textbox:
                    _Xpos = 150;
                    ControlCount += 1;
                    _Ypos = 20 * ControlCount;

                    Declaration = TAB2 + "this.txt" + FieldDef.name + " = new System.Windows.Forms.TextBox();" + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "// txt" + FieldDef.name + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".Location = new System.Drawing.Point(" + _Xpos.ToString() + ", " + _Ypos.ToString() + ");" + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".MaxLength = " + FieldDef.size.ToString() + ";" + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".Name = " + QUOTE + "txt" + FieldDef.name + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".Size = new System.Drawing.Size(100, 20);" + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".TabIndex = " + ControlCount.ToString() + ";" + NEWLINE;
                    Body += TAB2 + "this.txt" + FieldDef.name + ".TextChanged += new System.EventHandler(this.txt" + FieldDef.name + "_TextChanged);";
                    tControl.Declaration = Declaration;
                    tControl.Body = Body;
                    tControl.ControlName = "txt" + FieldDef.name;
                    tControl.VarDec = TAB1 + "private System.Windows.Forms.TextBox " + tControl.ControlName + ";" + NEWLINE;
                    htbTempControls.Add(tControl.ControlName, tControl);
                    MakeControl(ControlType.Label, FieldDef, ref ControlCount, ref htbTempControls);
                    break;

                case ControlType.udcComboForUI:
                    _Xpos = 150;
                    ControlCount += 1;
                    _Ypos = 20 * ControlCount;

                    Declaration = TAB2 + "this.udcComboForUI" + FieldDef.name + " = new udcComboForUI();" + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "// udcComboForUI" + FieldDef.name + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".Location = new System.Drawing.Point(" + _Xpos.ToString() + ", " + _Ypos.ToString() + ");" + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".MaxLength = " + FieldDef.size.ToString() + ";" + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".Name = " + QUOTE + "udcComboForUI" + FieldDef.name + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".Size = new System.Drawing.Size(100, 20);" + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".TabIndex = " + ControlCount.ToString() + ";" + NEWLINE;
                    Body += TAB2 + "this.udcComboForUI" + FieldDef.name + ".SelectedValueChanged += new System.EventHandler(this.udcComboForUI" + FieldDef.name + "_SelectedValueChanged);";
                    tControl.Declaration = Declaration;
                    tControl.Body = Body;
                    tControl.ControlName = "udcComboForUI" + FieldDef.name;
                    tControl.VarDec = TAB1 + "private udcComboForUI " + tControl.ControlName + ";" + NEWLINE;
                    htbTempControls.Add(tControl.ControlName, tControl);
                    MakeControl(ControlType.Label, FieldDef, ref ControlCount, ref htbTempControls);
                    break;

                
                case ControlType.Label:

                    _Xpos = 20;
                    int Ypos = _Ypos+3;
           

                    Declaration = TAB2 + "this.lbl" + FieldDef.name + " = new System.Windows.Forms.Label();" + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "// lbl" + FieldDef.name + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".AutoSize = true;" + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".Location = new System.Drawing.Point(" + _Xpos.ToString() + ", " + Ypos.ToString() + ");" + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".Name = " + QUOTE + "lbl" + FieldDef.name + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".Size = new System.Drawing.Size(100, 20);" + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".Name = " + QUOTE + "lbl" + FieldDef.name + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.lbl" + FieldDef.name + ".Text = " + QUOTE + UiSupport.FormatName(FieldDef.name) + QUOTE + ";" + NEWLINE;

                    tControl.Declaration = Declaration;
                    tControl.Body = Body;
                    tControl.ControlName = "lbl" + FieldDef.name;
                    tControl.VarDec = TAB1 + "private System.Windows.Forms.Label " + tControl.ControlName + ";" + NEWLINE;
                    htbTempControls.Add(tControl.ControlName, tControl);
                    break;

                case ControlType.CheckBox:

                    _Xpos = 150;
                    ControlCount += 1;
                    _Ypos = (20 * ControlCount);

                    Declaration = TAB2 + "this.chk" + FieldDef.name + " = new System.Windows.Forms.CheckBox();" + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "// chk" + FieldDef.name + NEWLINE;
                    Body += TAB2 + "// " + NEWLINE;
                    Body += TAB2 + "this.chk" + FieldDef.name + ".CheckAlign = System.Drawing.ContentAlignment.MiddleRight;";
         
                    Body += TAB2 + "this.chk" + FieldDef.name + ".AutoSize = true;";
                    Body += TAB2 + "this.chk" + FieldDef.name + ".Location = new System.Drawing.Point(" + _Xpos.ToString() + ", " + (_Ypos+4).ToString() + ");" + NEWLINE;
                    Body += TAB2 + "this.chk" + FieldDef.name + ".Name = " + QUOTE + "chk" + FieldDef.name + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.chk" + FieldDef.name + ".Size = new System.Drawing.Size(100, 20);" + NEWLINE;
                    Body += TAB2 + "this.chk" + FieldDef.name + ".Name = " + QUOTE + "chk" + FieldDef.name + QUOTE + ";" + NEWLINE;
                   // Body += TAB2 + "this.chk" + FieldDef.name + ".Text = " + QUOTE + UiSupport.FormatName(FieldDef.name) + QUOTE + ";" + NEWLINE;
                    Body += TAB2 + "this.chk" + FieldDef.name + ".CheckedChanged += new System.EventHandler(this.chk" + FieldDef.name + "_CheckedChanged);";

                    tControl.Declaration = Declaration;
                    tControl.Body = Body;
                    tControl.ControlName = "chk" + FieldDef.name;
                    tControl.VarDec = TAB1 + "private System.Windows.Forms.CheckBox " + tControl.ControlName + ";" + NEWLINE;
                    htbTempControls.Add(tControl.ControlName, tControl);
                    MakeControl(ControlType.Label, FieldDef, ref ControlCount, ref htbTempControls);
                    break;

                default:
                    break;
            }


        }


        private enum ControlType
        {
            Textbox,
            Label,
            CheckBox,
            udcComboForUI
        }
    }
}
