using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;

namespace RH
{
    public class ClassGenerator4
    {
     
        #region private constants

        private const string class_TEMPLATE = "class.txt";

        private const string PROPERTY_TEMPLATE = "property.txt";
        private const string PROPERTY_VARS_TEMPLATE = "propertyvar.txt";
        private const string POPULATE_VALUES_VARS_TEMPLATE = "populatevaluesvars.txt";
        private const string POPULATE_VALUES_PARAMS_TEMPLATE = "populatevaluesparams.txt";


        private const string POPULATE_SQL_TEMPLATE = "sp_populate.txt";
        private const string POPULATES_SQL_TEMPLATE = "sp_populates.txt";
        private const string POPULATE_SQL_ARGS_TEMPLATE = "sp_populateargs.txt";
        private const string POPULATE_SQL_FIELDS_TEMPLATE = "sp_populatefields.txt";
        private const string POPULATE_SQL_WHERE_TEMPLATE = "sp_populatewhere.txt";
      
        private const string SAVE_VARS_TEMPLATE = "savevars.txt";
        private const string SAVE_SQL_TEMPLATE = "sp_save.txt";
        private const string SAVE_SQL_ARGS_TEMPLATE = "sp_saveargs.txt";
        private const string SAVE_SQL_ARGS_COMMENT_TEMPLATE = "sp_saveargscomment.txt";

        private const string SAVEUPDATE_SQL_FIELDS_TEMPLATE = "sp_saveupdatefields.txt";
        private const string SAVEINSERT_SQL_VALUES_TEMPLATE = "sp_saveinsertvalues.txt";
        private const string SAVEINSERT_SQL_FIELDS_TEMPLATE = "sp_saveinsertfields.txt";
        private const string SAVE_SQL_VALUES_TEMPLATE = "sp_savevalues.txt";
        private const string SAVE_WHERE_TEMPLATE = "sp_savewhere.txt";


        private const string DELETE_PARAMS_TEMPLATE = "deleteparams.txt";
        private const string DELETE_SQL_TEMPLATE = "sp_delete.txt";
        private const string DELETE_SQL_ARGS_TEMPLATE = "sp_deleteargs.txt";
        private const string DELETE_SQL_WHERE_TEMPLATE = "sp_deletewhere.txt";

        private const string HTML_TEMPLATE = "html.txt";
        private const string HTML_FIELDS_TEMPLATE = "htmlfields.txt";

        private const string VB_DISPLAY_TEMPLATE = "vbdisplay.txt";
        private const string VB_DISPLAY_FIELDS_TEMPLATE = "vbdisplayfields.txt";
        private const string VB_DISPLAY_KEY_FIELDS_TEMPLATE = "vbdisplaykeyfields.txt";
        private const string VB_SAVE_TEMPLATE = "vbsave.txt";
        private const string VB_SAVE_FIELDS_TEMPLATE = "vbsavefields.txt";
        private const string VB_SAVE_VALIDATION_TEMPLATE = "vbsavevalidation.txt";
        #endregion

        #region private Variables

        private string _TemplatePath;
        private string _OutputPath;
        private Hashtable _htbTemplates;
        private Hashtable _htbMapInfo;
        private string _MadeClass = "";
      

        #endregion

        #region Constructor

        public ClassGenerator4( string p_sTemplatePath, string p_sOutputPath)
        {
            _TemplatePath = p_sTemplatePath;
            _OutputPath = p_sOutputPath;
        }

        #endregion

        #region private Methods

        private string GetTemplate(string p_sFilename)
        {
            if (_htbTemplates == null)
            {
                _htbTemplates = new Hashtable();
            }

            if (_htbTemplates.ContainsKey(p_sFilename))
            {
                return _htbTemplates[p_sFilename].ToString();
            }

            else
            {
                _htbTemplates.Add(p_sFilename, LoadTemplate(_TemplatePath + p_sFilename));
                return _htbTemplates[p_sFilename].ToString();
            }
        }

        private string formatFieldName(string p_sName)
        {

            string FieldName;
            FieldName = "";
            if (p_sName.Length == 0)
            {
                return "";
            }
            if (!((p_sName.IndexOf("_") > 0) | ((p_sName.IndexOf(" ") > 0))))
            {
                return p_sName.Substring(0, 1).ToUpper() + p_sName.Substring(1);
            }

            p_sName = p_sName.Substring(0, 1).ToUpper() + p_sName.Substring(1);

            for (int nCounter = 0; nCounter < p_sName.Length; nCounter++)
            {
                if ((p_sName.Substring(nCounter, 1) == "_") | (p_sName.Substring(nCounter, 1) == " "))
                {
                    if (nCounter < p_sName.Length - 1)
                    {
                        nCounter += 1;
                        FieldName += p_sName.Substring(nCounter, 1).ToUpper();
                    }
                }
                else
                {
                    FieldName += p_sName.Substring(nCounter, 1);
                }
            }
            return FieldName;
        }

        private string ParseTemplate(string p_sTemplateName, strTypeInfo p_strFieldTypeInfo)
        {
            string ParseTemplate;
            string Quote = "hh";

            ParseTemplate = GetTemplate(p_sTemplateName);

            if (p_strFieldTypeInfo.IsKeyField)
            {
                ParseTemplate = ParseTemplate.Replace("[inputoutput]","output" );
            }
            else
            {
                ParseTemplate = ParseTemplate.Replace("[inputoutput]", "");
            }

            ParseTemplate = ParseTemplate.Replace("[field]", p_strFieldTypeInfo.FieldName);
            ParseTemplate = ParseTemplate.Replace("[originaltype]", p_strFieldTypeInfo.OriginalType);
            ParseTemplate = ParseTemplate.Replace("[vbtype]", p_strFieldTypeInfo.CsharpType);
            ParseTemplate = ParseTemplate.Replace("[typeprefix]", p_strFieldTypeInfo.TypePrefix);
            ParseTemplate = ParseTemplate.Replace("[dbfield]", p_strFieldTypeInfo.DBFieldName);
            ParseTemplate = ParseTemplate.Replace("[readertype]", p_strFieldTypeInfo.ReaderType);
            ParseTemplate = ParseTemplate.Replace("[oledbtype]", p_strFieldTypeInfo.OleDBType);

            if (p_strFieldTypeInfo.SizeValid)
            {
                ParseTemplate = ParseTemplate.Replace("[size]", ", " + p_strFieldTypeInfo.Size.ToString());
                ParseTemplate = ParseTemplate.Replace("[paramsize]", "(" + p_strFieldTypeInfo.Size.ToString() + ")");
                ParseTemplate = ParseTemplate.Replace("[htmlsize]", " maxlength =" + Quote + p_strFieldTypeInfo.Size.ToString() + Quote);
            }
            else
            {
                ParseTemplate = ParseTemplate.Replace("[size]", "");
                ParseTemplate = ParseTemplate.Replace("[paramsize]", "");
                ParseTemplate = ParseTemplate.Replace("[htmlsize]", "");
            }

            ParseTemplate = ParseTemplate.Replace("[dbfield]", p_strFieldTypeInfo.DBFieldName);

            if (p_strFieldTypeInfo.CastFunction.Length > 0)
            {
                ParseTemplate = ParseTemplate.Replace("[cast]", p_strFieldTypeInfo.CastFunction + "(");
                ParseTemplate = ParseTemplate.Replace("[endcast]", ")");
            }
            else if (p_strFieldTypeInfo.SizeValid)
            {
                ParseTemplate = ParseTemplate.Replace("[cast]", "Left(");
                ParseTemplate = ParseTemplate.Replace("[endcast]", " , " + "(" + p_strFieldTypeInfo.Size + ")");
            }
            else
            {
                ParseTemplate = ParseTemplate.Replace("[cast]", "");
                ParseTemplate = ParseTemplate.Replace("[endcast]", "");
            }

            if (p_strFieldTypeInfo.TypeCheckFunction.Length > 0)
            {
                ParseTemplate = ParseTemplate.Replace("[typecheck]", p_strFieldTypeInfo.TypeCheckFunction + "(");
                ParseTemplate = ParseTemplate.Replace("[endtypecheck]", ")");
            }

            return ParseTemplate;
        }

        private string LoadTemplate(string p_sFullPath)
        {
            StreamReader Template = new StreamReader(p_sFullPath);
            string ReadData;
            ReadData = Template.ReadToEnd();
            Template.Close();
            return ReadData;
        }

        private void SaveCode(string p_sFullPath, string p_sContent)
        {


            StringWriter newCode = new StringWriter();
            StreamWriter St = new StreamWriter(p_sFullPath, false);
            St.Write(p_sContent);

            St.Close();


        }

        private strTypeInfo GetCodeDbMappingType(string p_sType)
        {

            if (_htbMapInfo == null)
            {
                ReadCodeToDbMappingTypes(_TemplatePath + "sybase.cfg");
            }

            if (_htbMapInfo.ContainsKey(p_sType.ToLower()))
            {
                return (strTypeInfo)_htbMapInfo[p_sType.ToLower()];
            }
            else
            {
                throw new ApplicationException("Unable to find Type >" + p_sType + "<");
            }



        }

        private void ReadCodeToDbMappingTypes(string p_sFullPath)
        {

            StreamReader MapInfo = new StreamReader(p_sFullPath);
            string sReadLine;
            strTypeInfo strFieldTypeInfo;
            _htbMapInfo = new Hashtable();
            string[] sSplitData;
            //tring[] sParts = new string[8];
            while (!MapInfo.EndOfStream)
            {
                sReadLine = MapInfo.ReadLine();
                sSplitData = sReadLine.Split(',');
                strFieldTypeInfo = new strTypeInfo();
                strFieldTypeInfo.OriginalType = sSplitData[0];
                strFieldTypeInfo.CsharpType = sSplitData[1];
                strFieldTypeInfo.TypePrefix = sSplitData[2];
                strFieldTypeInfo.CastFunction = sSplitData[3];
                strFieldTypeInfo.TypeCheckFunction = sSplitData[4];
                strFieldTypeInfo.ReaderType = sSplitData[5];
                strFieldTypeInfo.OleDBType = sSplitData[6];
                strFieldTypeInfo.SizeValid = (sSplitData[7].ToUpper() == "Y" ? true : false);
                _htbMapInfo.Add(sSplitData[0], strFieldTypeInfo);
            }
            MapInfo.Close();


        }

        #endregion

        #region public Methods

        public void MakeClassAndSqlForTable(ref MDTableDef Table,string ClassNamePrefix, string OutputPath)
        {

          
            string sProperties;
            string sPropertyClassLevelVars = "";

            string sPopulateValuesVars = "";
            string sPopulateValuesParams = "";
            string sPopulateSQLArgs = "";
            string sPopulateSQLFields = "";
            string sPopulateSQLWhere = "";

            string sSaveVars = "";
            string sSaveSQLArgs = "";
            string sSaveSQLArgsComment = "";
            string sSaveInsertSQLFields = "";
            string sSaveUpdateSQLFields = "";
            string sSaveInsertSQLValues = "";

            string sSaveSQLWhere = "";
            string sSaveSQLValues = "";

            string sDeleteParams = "";
            string sDeleteSQLArgs = "";
            string sDeleteSQLWhere = "";

            string sHTMLFields = "";
            string sVBAllFields = "";
            string sVBDisplayFields = "";
            string sVBDisplayKeyFields = "";
            string sVBSaveFields = "";
            string sVBSaveValidations = "";
            string sKeyFieldName = "";
            string sDbKeyFieldName = "";
            string ClassNameWithPrefix;

            strTypeInfo strFieldTypeInfo;


            ClassNameWithPrefix = ClassNamePrefix;

            sProperties = "";
          
            foreach (MDFieldDef FieldDef in Table.fields)
            {


                if (!FieldDef.isTimeStamp)
                {
                    
               
                strFieldTypeInfo = GetCodeDbMappingType(FieldDef.fieldType);
                if (strFieldTypeInfo.SizeValid)
                {
                    strFieldTypeInfo.Size = Convert.ToInt32(FieldDef.size);
                }
                strFieldTypeInfo.FieldName = formatFieldName(FieldDef.name);
                strFieldTypeInfo.DBFieldName = FieldDef.name;

                sProperties += ParseTemplate(PROPERTY_TEMPLATE, strFieldTypeInfo);
                sPropertyClassLevelVars += ParseTemplate(PROPERTY_VARS_TEMPLATE, strFieldTypeInfo) +"\r\n" ;
                // +Convert.ToChar(14);


                if (FieldDef.isIdentity)
                {

                    ClassNameWithPrefix = ClassNameWithPrefix + strFieldTypeInfo.FieldName.Substring(2);
                    Table.ClassNameWithPrefix = ClassNameWithPrefix;
                    Table.ClassName = strFieldTypeInfo.FieldName.Substring(2); 

                    //KEYs
                    sKeyFieldName = strFieldTypeInfo.FieldName;
                    sDbKeyFieldName = strFieldTypeInfo.DBFieldName;

                    strFieldTypeInfo.IsKeyField = true;

                    sPopulateValuesParams += ParseTemplate(POPULATE_VALUES_PARAMS_TEMPLATE, strFieldTypeInfo);
                    sPopulateSQLArgs += ParseTemplate(POPULATE_SQL_ARGS_TEMPLATE, strFieldTypeInfo);
                    sPopulateSQLWhere += ParseTemplate(POPULATE_SQL_WHERE_TEMPLATE, strFieldTypeInfo);

                    sSaveSQLWhere += ParseTemplate(SAVE_WHERE_TEMPLATE, strFieldTypeInfo);

                    sDeleteParams += ParseTemplate(DELETE_PARAMS_TEMPLATE, strFieldTypeInfo);
                    sDeleteSQLArgs += ParseTemplate(DELETE_SQL_ARGS_TEMPLATE, strFieldTypeInfo);
                    sDeleteSQLWhere += ParseTemplate(DELETE_SQL_WHERE_TEMPLATE, strFieldTypeInfo);

                    sVBDisplayKeyFields += ParseTemplate(VB_DISPLAY_KEY_FIELDS_TEMPLATE, strFieldTypeInfo);
                }
                else
                {
                    strFieldTypeInfo.IsKeyField = false;
                    //sPopulateValuesVars += ParseTemplate(POPULATE_VALUES_VARS_TEMPLATE, strFieldTypeInfo)

                    sSaveUpdateSQLFields += ParseTemplate(SAVEUPDATE_SQL_FIELDS_TEMPLATE, strFieldTypeInfo);

                    sSaveInsertSQLFields += ParseTemplate(SAVEINSERT_SQL_FIELDS_TEMPLATE, strFieldTypeInfo);
                    sSaveInsertSQLValues += ParseTemplate(SAVEINSERT_SQL_VALUES_TEMPLATE, strFieldTypeInfo);

                    sVBDisplayFields += ParseTemplate(VB_DISPLAY_FIELDS_TEMPLATE, strFieldTypeInfo);
                    sSaveSQLValues += ParseTemplate(SAVE_SQL_VALUES_TEMPLATE, strFieldTypeInfo);
                    sSaveVars += ParseTemplate(SAVE_VARS_TEMPLATE, strFieldTypeInfo);
                }



                sVBAllFields += ParseTemplate(VB_DISPLAY_FIELDS_TEMPLATE, strFieldTypeInfo);
                sPopulateValuesVars += ParseTemplate(POPULATE_VALUES_VARS_TEMPLATE, strFieldTypeInfo);
                //sInsertVars += ParseTemplate(INSERT_VARS_TEMPLATE, strFieldTypeInfo)
                //sSaveVars += ParseTemplate(SAVE_VARS_TEMPLATE, strFieldTypeInfo);

                sPopulateSQLFields += ParseTemplate(POPULATE_SQL_FIELDS_TEMPLATE, strFieldTypeInfo);

                sSaveSQLArgs += ParseTemplate(SAVE_SQL_ARGS_TEMPLATE, strFieldTypeInfo);
                sSaveSQLArgsComment += ParseTemplate(SAVE_SQL_ARGS_COMMENT_TEMPLATE, strFieldTypeInfo);
               
                sHTMLFields += ParseTemplate(HTML_FIELDS_TEMPLATE, strFieldTypeInfo);

                sVBSaveFields += ParseTemplate(VB_SAVE_FIELDS_TEMPLATE, strFieldTypeInfo);

                if (strFieldTypeInfo.TypeCheckFunction.Length > 0)
                {
                    sVBSaveValidations += ParseTemplate(VB_SAVE_VALIDATION_TEMPLATE, strFieldTypeInfo);
                }
            }
            }

            string sclassOutput;
            string sPopulateSQLOutput;
            string sPOPULATESSQLOutput;
            string sSaveSQLOutput;
            string sDeleteSQLOutput;
          
            string sDropPart;
            string sCreatePart;

            //CREATE THE CLASS OUTPUT
            sclassOutput = GetTemplate(class_TEMPLATE);
           // sclassOutput = sclassOutput.Replace("[classname]", p_sclassName);
            sclassOutput = sclassOutput.Replace("[propertyvars]", sPropertyClassLevelVars);
            sclassOutput = sclassOutput.Replace("[properties]", sProperties);
            sclassOutput = sclassOutput.Replace("[tablename]", Table.name);
            sclassOutput = sclassOutput.Replace("[populatevars]", sPopulateValuesVars);
            sclassOutput = sclassOutput.Replace("[populateparams]", sPopulateValuesParams);
            sclassOutput = sclassOutput.Replace("[savevars]", sSaveVars);
            sclassOutput = sclassOutput.Replace("[deleteparams]", sDeleteParams);
            sclassOutput = sclassOutput.Replace("[assignvars]", sVBSaveFields);
            sclassOutput = sclassOutput.Replace("[displayvars]", sVBAllFields);
            sclassOutput = sclassOutput.Replace("[vbkey]", formatFieldName(sKeyFieldName));
            sclassOutput = sclassOutput.Replace("[dbkey]", sDbKeyFieldName);
            sclassOutput = sclassOutput.Replace("[classname]", ClassNameWithPrefix);
            //  [insertvars],SAVE_VARS_TEMPLATE
            SaveCode(_OutputPath + ClassNameWithPrefix + ".cs", sclassOutput);

            //CREATE THE POPULATE SQL
            sPopulateSQLArgs = MyTrimEnd(sPopulateSQLArgs, ",");
            sPopulateSQLFields = MyTrimEnd(sPopulateSQLFields, ",");
            sPopulateSQLWhere = MyTrimEnd(sPopulateSQLWhere, "AND");
            sPopulateSQLOutput = GetTemplate(POPULATE_SQL_TEMPLATE);
            sPopulateSQLOutput = sPopulateSQLOutput.Replace("[tablename]", Table.name);
            sPopulateSQLOutput = sPopulateSQLOutput.Replace("[args]", sPopulateSQLArgs);
            sPopulateSQLOutput = sPopulateSQLOutput.Replace("[fields]", sPopulateSQLFields);
            sPopulateSQLOutput = sPopulateSQLOutput.Replace("[where]", sPopulateSQLWhere);
         
            sDropPart = sPopulateSQLOutput.Substring(0,sPopulateSQLOutput.IndexOf("CREATE PROCEDURE")-1);
            sCreatePart = sPopulateSQLOutput.Substring(sPopulateSQLOutput.IndexOf("CREATE PROCEDURE"));
            XDatabase.CreateSQLCommand(sDropPart);
            XDatabase.ExecuteCommand();
            XDatabase.CreateSQLCommand(sCreatePart);
            XDatabase.ExecuteCommand();

            //CREATE THE POPULATESSSSSSSSSSSSS SQL

            sPOPULATESSQLOutput = GetTemplate(POPULATES_SQL_TEMPLATE);
            sPOPULATESSQLOutput = sPOPULATESSQLOutput.Replace("[tablename]", Table.name);
            sPOPULATESSQLOutput = sPOPULATESSQLOutput.Replace("[fields]", sPopulateSQLFields);

            sDropPart = sPOPULATESSQLOutput.Substring(0, sPOPULATESSQLOutput.IndexOf("CREATE PROCEDURE") - 1);
            sCreatePart = sPOPULATESSQLOutput.Substring(sPOPULATESSQLOutput.IndexOf("CREATE PROCEDURE"));
            XDatabase.CreateSQLCommand(sDropPart);
            XDatabase.ExecuteCommand();
            XDatabase.CreateSQLCommand(sCreatePart);
            XDatabase.ExecuteCommand();

          
            //CREATE THE SAVE SQL
            sSaveSQLWhere = MyTrimEnd(sSaveSQLWhere, "AND");

            sSaveSQLArgs = MyTrimEnd(sSaveSQLArgs, ",");
            sSaveInsertSQLFields = MyTrimEnd(sSaveInsertSQLFields, ",");
            sSaveSQLWhere = MyTrimEnd(sSaveSQLWhere, "AND");

            sSaveSQLOutput = GetTemplate(SAVE_SQL_TEMPLATE);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[tablename]", Table.name);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[args]", sSaveSQLArgs);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[argscomment]", sSaveSQLArgsComment);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[saveupdatefields]", sSaveUpdateSQLFields);

            sSaveSQLOutput = sSaveSQLOutput.Replace("[saveinsertfields]", sSaveInsertSQLFields);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[savevalues]", sSaveSQLValues);


            sSaveSQLOutput = sSaveSQLOutput.Replace("[where]", sSaveSQLWhere);
            sSaveSQLOutput = sSaveSQLOutput.Replace("[dbkey]", sKeyFieldName);
           // SaveCode(_OutputPath + "sp_" + Table.name + "_SAVE.sql", sSaveSQLOutput);

            sDropPart = sSaveSQLOutput.Substring(0, sSaveSQLOutput.IndexOf("CREATE PROCEDURE") - 1);
            sCreatePart = sSaveSQLOutput.Substring(sSaveSQLOutput.IndexOf("CREATE PROCEDURE"));
            XDatabase.CreateSQLCommand(sDropPart);
            XDatabase.ExecuteCommand();
            XDatabase.CreateSQLCommand(sCreatePart);
            XDatabase.ExecuteCommand();

            //CREATE THE DELETE SQL
            sDeleteSQLArgs = MyTrimEnd(sDeleteSQLArgs, ",");
            sDeleteSQLWhere = MyTrimEnd(sDeleteSQLWhere, "AND");
            sDeleteSQLOutput = GetTemplate(DELETE_SQL_TEMPLATE);
            sDeleteSQLOutput = sDeleteSQLOutput.Replace("[tablename]", Table.name);
            sDeleteSQLOutput = sDeleteSQLOutput.Replace("[args]", sDeleteSQLArgs);
            sDeleteSQLOutput = sDeleteSQLOutput.Replace("[where]", sDeleteSQLWhere);
            sDeleteSQLOutput = sDeleteSQLOutput.Replace("[dbkey]", sKeyFieldName);
           // SaveCode(_OutputPath + "sp_" + Table.name + "_DELETE.sql", sDeleteSQLOutput);

            sDropPart = sDeleteSQLOutput.Substring(0, sDeleteSQLOutput.IndexOf("CREATE PROCEDURE") - 1);
            sCreatePart = sDeleteSQLOutput.Substring(sDeleteSQLOutput.IndexOf("CREATE PROCEDURE"));
            XDatabase.CreateSQLCommand(sDropPart);
            XDatabase.ExecuteCommand();
            XDatabase.CreateSQLCommand(sCreatePart);
            XDatabase.ExecuteCommand();


            //CREATE THE HTML
            //sHTMLOutput = GetTemplate(HTML_TEMPLATE);
            //sHTMLOutput = sHTMLOutput.Replace("[fields]", sHTMLFields);
            //SaveCode(_OutputPath + ClassNameWithPrefix + ".html", sHTMLOutput);

            //CREATE THE SOURCECODE
            //sCsharpDisplayOutput = GetTemplate(VB_DISPLAY_TEMPLATE);
            //sCsharpDisplayOutput = sCsharpDisplayOutput.Replace("[keyfields]", sVBDisplayKeyFields);
            //sCsharpDisplayOutput = sCsharpDisplayOutput.Replace("[fields]", sVBDisplayFields);
            //sCsharpDisplayOutput = sCsharpDisplayOutput.Replace("[classname]", ClassNameWithPrefix);
            //SaveCode(_OutputPath + ClassNameWithPrefix + "_display.vb", sCsharpDisplayOutput);

            //sCsharpUpdateOutput = GetTemplate(VB_SAVE_TEMPLATE);
            //sCsharpUpdateOutput = sCsharpUpdateOutput.Replace("[classname]", ClassNameWithPrefix);
            //sCsharpUpdateOutput = sCsharpUpdateOutput.Replace("[fields]", sVBSaveFields);
            //sCsharpUpdateOutput = sCsharpUpdateOutput.Replace("[validation]", sVBSaveValidations);
            //SaveCode(_OutputPath + ClassNameWithPrefix + "_update.vb", sCsharpUpdateOutput);


            _MadeClass = sclassOutput;
          
        }
        #endregion

        #region Properties

        public string MadeClass
        {
            get
            {
                return _MadeClass;
            }
        }
 
        private string MyTrimEnd(string p_sData, string p_sTrim)
        {
            int pos = 0;
            pos = p_sData.LastIndexOf(p_sTrim);
            if (pos == -1)
            {
                return p_sData;
            }
            else
            {
                string x;
                x = p_sData.Substring(0, pos);
                return x;
            }

        }
        #endregion
    }
}

