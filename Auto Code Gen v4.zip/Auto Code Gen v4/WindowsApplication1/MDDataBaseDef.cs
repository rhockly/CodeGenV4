using System.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using System.Data.Odbc;
using System.Data.Common;


namespace RH
{
    public class MDDataBaseDef
    {
        private List<MDTableDef> _tableList;

        public MDDataBaseDef()
        {
            _tableList = new List<MDTableDef>();
        }

        public List<MDTableDef> tableList
        {
            get { return _tableList; }
        }

        public MDTableDef GetTableDef(string TableName)
        {
            foreach (MDTableDef def in tableList)
                if (def.name == TableName)
                    return def;
            return null;
        }

        public void ExtractTables()
        {
            tableList.Clear();
            string defaultTsField = "TS";
            string defaultIdField = "ID";
            string defaultFkField = "ID";
            string defaultTablePrefix = "TBL";
            string tableName = "";
            string test;


            DataTable table = XDatabase.GetSchemaTables();


            {
                foreach (System.Data.DataRow row in table.Rows)
                {
                    foreach (System.Data.DataColumn col in table.Columns)
                    {

                        tableName = row["TABLE_NAME"].ToString();
                        if (tableName.Substring(0, defaultTablePrefix.Length).ToLower() == defaultTablePrefix.ToLower())
                        {

                            MDTableDef tdef = new MDTableDef();
                            tdef.name = tableName;
                            tdef.ForeignIdName = tableName.Substring(defaultTablePrefix.Length);
                            if (!tableList.Contains(tdef))
                            {
                                tableList.Add(tdef);
                            }

                        }

                    }
                }
            }


            foreach (MDTableDef TableDefinition in tableList)
            {

                MDTableDef TableDefinitionPass = TableDefinition;
                DataTable tableSchema = XDatabase.GetSchemaColumns(ref TableDefinitionPass);
                foreach (System.Data.DataRow defRow in tableSchema.Rows)
                {
                    MDFieldDef field = null;

                    if (TableDefinition.name.Equals(defRow[2]))
                    {
                        int fieldSize = 0;
                        Int32.TryParse(defRow[8].ToString(), out fieldSize);
                        field = new MDFieldDef(defRow[3].ToString(), FieldTypeToCorrectCase(defRow[7].ToString()), fieldSize);

                        //TS
                        if (field.name.ToLower() == defaultTsField.ToLower())
                        {
                            field.isTimeStamp = true;
                        }

                        //ID
                        if (field.name.Length > defaultIdField.Length)
                        {
                            test = field.name.Substring(0, defaultIdField.Length);

                            if (test.ToLower() == defaultIdField.ToLower())
                            {
                                field.isIdentity = true;
                            }
                        }

                        //FK
                        if (field.name.Length > defaultFkField.Length)
                        {
                            test = field.name.Substring(field.name.Length - defaultFkField.Length, defaultFkField.Length);

                            if (test.ToLower() == defaultFkField.ToLower())
                            {
                                field.isForeignKey = true;

                            }
                        }

                        TableDefinition.fields.Add(field);
                    }
                }

            }

            //Look for foreign keys
            foreach (MDTableDef TableDefinition in tableList)
            {
                foreach (MDFieldDef def in TableDefinition.fields)
                {
                    if (def.isForeignKey)
                    {
                        string FindTable = defaultTablePrefix + def.name.Substring(0, def.name.Length - defaultFkField.Length);
                        foreach (MDTableDef innerTableDefinition in tableList)
                        {
                            if (innerTableDefinition.name.ToLower() == FindTable.ToLower())
                            {
                                def.relatesToTable = innerTableDefinition.name;
                                break;
                            }
                        }
                    }
                }

            }



        }

        private string GetOleDbFieldType(string p)
        {
            switch (p)
            {
                case "2":
                case "5":
                case "3":
                    return "Integer";
                case "7":
                    return "Datetime";
                case "130":
                    return "Char";
                default:
                    return "DbMetaData.GetOleDbFieldType : Unknown:" + p.ToString();
            }
        }

        static public string FieldTypeToCorrectCase(string fType)
        {
            string[] originals =  {
                "BigInt",
                "Binary",
                "Bit",
                "Char",
                "DateTime",
                "Decimal",
                "Float",
                "Image",
                "Int",
                "Money",
                "NChar",
                "NText",
                "NVarChar",
                "Real",
                "UniqueIdentifier",
                "SmallDateTime",
                "SmallInt",
                "SmallMoney",
                "Text",
                "Timestamp",
                "TinyInt",
                "VarBinary",
                "VarChar",
                "Variant",
                "Xml",
                "Udt"};

            string lowerType = fType.ToLower();
            foreach (string s in originals)
                if (s.ToLower().Equals(lowerType))
                    return s;
            return "NULL";

        }

        static public string FieldTypeToLangType(string p)
        {
            switch (p.ToLower())
            {
                case "bigint":
                    return "Int64";//. A 64-bit signed integer.  
                case "binary":
                    return "Byte[]";//. A fixed-length stream of binary data ranging between 1 and 8,000 bytes.  
                case "bool":
                case "boolean":
                case "bit":
                    return "bool";//. An unsigned numeric value that can be 0, 1, or a null reference (Nothing in Visual Basic).  
                case "bstr":
                case "char":
                    return "string";//. A fixed-length stream of non-Unicode characters ranging between 1 and 8,000 characters.  
                case "date":
                case "dbdate":
                case "dbtime":
                case "dbtimestamp":
                case "datetime":
                    return "DateTime";//. Date and time data ranging in value from January 1, 1753 to December 31, 9999 to an accuracy of 3.33 milliseconds.  
                case "currency":
                case "decimal":
                    return "Decimal";//. A fixed precision and scale numeric value between -10 38 -1 and 10 38 -1.  
                case "double":
                case "float":
                    return "Double";//. A floating point number within the range of -1.79E +308 through 1.79E +308.  
                case "image":
                    return "Byte[]";//. A variable-length stream of binary data ranging from 0 to 2 31 -1 (or 2,147,483,647) bytes.  
                case "int":
                case "integer":
                    return "int";//. A 32-bit signed integer.  
                case "money":
                    return "Decimal";//. A currency value ranging from -2 63 (or -922,337,203,685,477.5808) to 2 63 -1 (or +922,337,203,685,477.5807) with an accuracy to a ten-thousandth of a currency unit.  
                case "nchar":
                    return "string";//. A fixed-length stream of Unicode characters ranging between 1 and 4,000 characters.  
                case "ntext":
                    return "string";//. A variable-length stream of Unicode data with a maximum length of 2 30 - 1 (or 1,073,741,823) characters.  
                case "nvarchar":
                    return "string";//. A variable-length stream of Unicode characters ranging between 1 and 4,000 characters. Implicit conversion fails if the string is greater than 4,000 characters. Explicitly set the object when working with strings longer than 4,000 characters.  
                case "real":
                    return "Single";//. A floating point number within the range of -3.40E +38 through 3.40E +38.  
                case "smalldatetime":
                    return "DateTime";//. Date and time data ranging in value from January 1, 1900 to June 6, 2079 to an accuracy of one minute.  
                case "smallint":
                    return "int";//. A 16-bit signed integer.  
                case "smallmoney":
                    return "Decimal";//. A currency value ranging from -214,748.3648 to +214,748.3647 with an accuracy to a ten-thousandth of a currency unit.  
                case "text":
                    return "String";//. A variable-length stream of non-Unicode data with a maximum length of 2 31 -1 (or 2,147,483,647) characters.  
                case "timestamp":
                    return "DateTime";//. Automatically generated binary numbers, which are guaranteed to be unique within a database. timestamp is used typically as a mechanism for version-stamping table rows. The storage size is 8 bytes.  
                case "tinyint":
                    return "Byte";//. An 8-bit unsigned integer.  
                case "udt":
                    throw new Exception("A SQL Server 2005 user-defined type (UDT) was encountered.");
                case "uniqueidentifier":
                    return "Guid";//. A globally unique identifier (or GUID).  
                case "varbinary":
                    return "Byte[]";//. A variable-length stream of binary data ranging between 1 and 8,000 bytes. Implicit conversion fails if the byte array is greater than 8,000 bytes. Explicitly set the object when working with byte arrays larger than 8,000 bytes.  
                case "varchar":
                    return "String";//. A variable-length stream of non-Unicode characters ranging between 1 and 8,000 characters.  
                case "variant":
                    return "Object";//. A special data type that can contain numeric, string, binary, or date data as well as the SQL Server values Empty and Null, which is assumed if no other type is declared.  
                case "xml":
                    return "string";
                default:
                    throw new Exception("DbMetadata.FieldTypeToLangType: Unknown DB Field Type " + p);
            }
        }

        //internal void AddLinkTable(string LeftTable, string linkTable, string LeftField, string RightField, string RightTable)
        //{
        //    OfwLinkTableDef ldef = new OfwLinkTableDef();
        //    ldef.LeftField = LeftField;
        //    ldef.LinkTableName = linkTable;
        //    ldef.RightTableName = RightTable;
        //    ldef.RightField = RightField;
        //    ldef.LeftTableName = LeftTable;

        //    _linkTableDic.Add(linkTable, ldef);
        //}

        internal void Clear()
        {
            tableList.Clear();
        }
    }
}
