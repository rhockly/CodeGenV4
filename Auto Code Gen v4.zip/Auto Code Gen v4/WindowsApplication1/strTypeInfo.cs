using System;
using System.Collections.Generic;
using System.Text;

namespace RH
{
    public struct strTypeInfo
    {
        public string FieldName;
        public string DBFieldName;
        public string OriginalType;
        public string CsharpType;
        public string TypePrefix;
        public string CastFunction;
        public string TypeCheckFunction;
        public string ReaderType;
        public string OleDBType;
        public bool SizeValid;
        public int Size;
        public bool IsKeyField;
    }
}
