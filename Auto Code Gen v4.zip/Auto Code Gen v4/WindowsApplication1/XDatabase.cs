
using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using RH;

public class DBConnection
{
    #region class Methods
    //--------------------------------------------------------------------------
    //   Name        :   GetConnectionstring
    //   Description :   Retreives db_connectstring from app settings in 
    //                   web config file.
    //--------------------------------------------------------------------------
    public static string GetConnectionstring()
    {
        //'return System.Configuration.ConfigurationSettings.AppSettings("db_connectstring")
        //return "server=localhost;Initial Catalog=Ross;user id=sa;password=''";
      //  return "server=localhost;Initial Catalog=Ross;user id=sa;password='password'";
    return "Data Source=bozo;Initial Catalog=Ross;Integrated Security=True";
    }
    #endregion
}

public class XDatabase : DBConnection
{
    #region class Level Variables
    //--------------------------------------------------------------------------
    // class level variables.
    //--------------------------------------------------------------------------
    private static SqlCommand mCmd;
    private static SqlConnection mCon;
    private static SqlTransaction mTrans;
    private static int mnTransactionCount;
    #endregion

    #region class Methods

    //--------------------------------------------------------------------------
    //   Name        :   BeginTransaction
    //   Description :   Start a database transaction
    //--------------------------------------------------------------------------
    public static void BeginTransaction()
    {
        if (mnTransactionCount == 0)
        {
            if (mCon == null)
            {
                mCon = new SqlConnection(GetConnectionstring());
            }

            if (mCon.State == ConnectionState.Closed)
            {
                mCon.Open();
            }

            mTrans = mCon.BeginTransaction();
            mnTransactionCount = 1;
        }
        else
        {
            mnTransactionCount += 1;
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   RollBackTransaction
    //   Description :   Rolls back a database transaction
    //--------------------------------------------------------------------------
    public static void RollBackTransaction()
    {
        if (mnTransactionCount == 1)
        {
            mTrans.Rollback();
            mnTransactionCount = 0;
            KillConnection();
        }
        else
        {
            mnTransactionCount -= 1;
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   CommitTransaction
    //   Description :   Commit the current DB transction.
    //--------------------------------------------------------------------------
    public static void CommitTransaction()
    {

        // Commit transaction.
        if (mnTransactionCount == 1)
        {
            mTrans.Commit();
            mnTransactionCount = 0;
            KillConnection();
        }
        else
        {
            mnTransactionCount -= 1;
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   ExecuteSQL
    //   Description :   Executes SQL
    //                   parameters if ( any.
    //--------------------------------------------------------------------------

    public static void CreateSQLCommand(string sSQL)
    {

        // Set command object properties.
        mCmd = new SqlCommand();

        // Specif (y command runs in a transaction.
        if (!(mTrans == null))
        {
            mCmd.Transaction = mTrans;
        }
        mCmd.CommandTimeout = 30;
        mCmd.CommandType = CommandType.Text;
        mCmd.CommandText = sSQL;
      

    }

    public static void CreateCommand(string sSPName)
    {

        // Set command object properties.
        mCmd = new SqlCommand();

        // Specif (y command runs in a transaction.
        if (!(mTrans == null))
        {
            mCmd.Transaction = mTrans;
        }
        mCmd.CommandTimeout = 30;
        mCmd.CommandType = CommandType.StoredProcedure;
        mCmd.CommandText = sSPName;

    }
    public static void CreateCommand(string sSPName, ArrayList colParams)
    {

        // Set command object properties.
        mCmd = new SqlCommand();

        // Specif (y command runs in a transaction.
        if (!(mTrans == null))
        {
            mCmd.Transaction = mTrans;
        }
        mCmd.CommandTimeout = 30;
        mCmd.CommandType = CommandType.StoredProcedure;
        mCmd.CommandText = sSPName;

        // Add parameters, if ( any.
        if (!(colParams == null))
        {
            foreach (object prm in colParams)
            {
                mCmd.Parameters.Add(prm);
            }

        }

    }
    public static void CreateCommand(string sSPName, ArrayList colParams,int nTimeout)
    {

        // Set command object properties.
        mCmd = new SqlCommand();

        // Specif (y command runs in a transaction.
        if (!(mTrans == null))
        {
            mCmd.Transaction = mTrans;
        }
        mCmd.CommandTimeout = nTimeout;
        mCmd.CommandType = CommandType.StoredProcedure;
        mCmd.CommandText = sSPName;

        // Add parameters, if ( any.
        if (!(colParams == null))
        {
            foreach (object prm in colParams)
            {
                mCmd.Parameters.Add(prm);
            }

        }

    }
    //--------------------------------------------------------------------------
    //   Name        :   ExecuteCommand
    //   Description :   Execute the current command object.
    //--------------------------------------------------------------------------
    public static void ExecuteCommand()
    {

        //Open connection and execute
        SetUpConnection();
        mCmd.ExecuteNonQuery();

    }

    //--------------------------------------------------------------------------
    //   Name        :   returnDataSet
    //   Description :   return a dataset object for the current command object
    //--------------------------------------------------------------------------
    public static DataSet returnDataSet()
    {
        DataSet dtDataSet;
        SqlDataAdapter adpApt;
        // Create new dataset.
        dtDataSet = new DataSet();

        SetUpConnection();

        // Fill dataset and return.
        adpApt = new SqlDataAdapter(mCmd);
        adpApt.Fill(dtDataSet);
        return dtDataSet;

    }

    //--------------------------------------------------------------------------
    //   Name        :   returnDataReader
    //   Description :   return a SqlDataReader object for the current command object
    //--------------------------------------------------------------------------
    public static SqlDataReader returnDataReader()
    {
        SqlDataReader oDataReader;

        SetUpConnection();

        oDataReader = mCmd.ExecuteReader();
        return oDataReader;

    }
    //--------------------------------------------------------------------------
    //   Name        :   returnDataTable
    //   Description :   return a datatable object for the current command object
    //--------------------------------------------------------------------------
    public static DataTable returnDataTable()
    {

        DataTable dtTable;
        SqlDataAdapter adpApt;

        // Create new dataset.
        dtTable = new DataTable();

        SetUpConnection();

        // Fill dataset and return.
        adpApt = new SqlDataAdapter(mCmd);
        adpApt.Fill(dtTable);
        return dtTable;

    }
    //--------------------------------------------------------------------------
    //   Name        :   KillConnection
    //   Description :   Shuts down the connection
    //--------------------------------------------------------------------------
    public static void KillConnection()
    {

        if (mnTransactionCount == 0)
        {

            if (!(mCmd == null))
            {
                mCmd.Dispose();
                mCmd = null;
            }

            if (!(mTrans == null))
            {
                mTrans.Dispose();
                mTrans = null;
            }

            if (!(mCon == null))
            {
                mCon.Dispose();
                mCon = null;
            }

        }
    }
    //--------------------------------------------------------------------------
    //   Name        :   SetUpConnection
    //   Description :   Checks the connection
    //--------------------------------------------------------------------------
    private static void SetUpConnection()
    {
        if (mCon == null)
        {
            mCon = new SqlConnection(GetConnectionstring());
        }

        if (mCon.State == ConnectionState.Closed)
        {
            mCon.Open();
        }

        mCmd.Connection = mCon;

    }
        
    
    #endregion
    public static DataTable GetSchemaTables()
    {
        if (mCon == null)
        {
            mCon = new SqlConnection(GetConnectionstring());
        }

        if (mCon.State == ConnectionState.Closed)
        {
            mCon.Open();
        }

        return mCon.GetSchema("Tables");

    }




    public static DataTable GetSchemaColumns(ref MDTableDef MDTableDef)
    {
        if (mCon == null)
        {
            mCon = new SqlConnection(GetConnectionstring());
        }

        if (mCon.State == ConnectionState.Closed)
        {
            mCon.Open();
        }

        string[] restrictions = new string[] { null, null, MDTableDef.name, null };
       return mCon.GetSchema("Columns", restrictions);

    }
}

public enum eSqlreturns
{
    Success = 0,
    RecordNotFound = 1,
    RecordAlreadyUpdated = 2,
    RecordNotUpdated = 3,
    RecordHasChildRecords = 5,
    RecordAlreadyExists = 6,
    IncorrectDataEntry=7,
    DeleteSuccessful=8,
    UpdateSuccessful = 9,
    CreateSuccessful = 10,
}

