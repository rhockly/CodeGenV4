using System.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using System.Data.Odbc;
using System.Data.Common;

namespace RH
{
    public class MDFieldDef
    {
        private string _name;
        private string _fieldType;
        private int _size;
        public bool markedForGUIGeneration;
        public bool isIdentity;
        public bool isTimeStamp;
        public bool isForeignKey;
        public string relatesToTable;

        public MDFieldDef()
        {
            isIdentity = false;
            isTimeStamp = false;
            isForeignKey = false;
            relatesToTable = "";
        }

        public MDFieldDef(string Name, string FieldType, int Size)
            : base()
        {
            this._name = Name;
            this.fieldType = FieldType;
            this.size = Size;
        }



        public string langType()
        {
            return MDDataBaseDef.FieldTypeToLangType(fieldType);
        }

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string fieldType
        {
            get { return _fieldType; }
            set { _fieldType = value; }
        }

        public int size
        {
            get { return _size; }
            set { _size = value; }
        }

    }
}
