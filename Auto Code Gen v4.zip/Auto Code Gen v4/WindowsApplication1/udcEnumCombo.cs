using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Text;


    public partial class udcComboEnum : System.Windows.Forms.ComboBox
    {
   
#region Class Methods

    //----PopulateEnum----------------------------------------------------------------------
    //   Name        :   PopulateEnum
    //   Description :   Attaches an Enumeration to a Combo box datasource.
    //                   ** Assumes that all enums are sequential values based from 1
    //   Author      :   AP
    //--------------------------------------------------------------------------
    //   Parameters  :   eLookup     - Enumeration data to use
    //                   cboCombo    - Combobox target
    //                   bShowEmpty  - Boolean to determine if an "(none)" entry should exist
    //   Returns     :   N/A
    //--------------------------------------------------------------------------
    public void PopulateEnum([enum] eLookup, bool bShowEmpty)
    {
        //[enum]

        ArrayList arrList = new ArrayList();
        //string str;
        //int iCount= 1;
        
        this.DropDownStyle =System.Windows.Forms.ComboBoxStyle.DropDownList;
        if (bShowEmpty)
	    {
		 arrList.Add(new EnumData(0, "(none)"));
	    }

       
        //For Each str In eLookup.GetNames(eLookup.GetType)
        //    arrList.Add(New EnumData(iCount, str))
        //    iCount += 1
        //Next
        this.DataSource = arrList;
        this.DisplayMember = "Data";
 
}
#endregion



}
public class EnumData
{

    int mnIndex;
    string msData;
    public EnumData(int nIndex, string sData)
        {
        mnIndex = nIndex;
        msData = sData;
         
        }

 

    public int Index
    {
        get
            {
            return  mnIndex;
            }
    }

 public string Data
    {
        get
        {
            return  msData;
        }
    }



    public void New(int nIndex, string sData)
{
        mnIndex = nIndex;
        msData = sData;
 }

}

