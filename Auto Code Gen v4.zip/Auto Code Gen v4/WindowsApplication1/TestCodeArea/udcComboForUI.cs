using System.Windows;
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Data;
public partial class udcComboForUI : udcCombo
    {
      
    
    public udcComboForUI()
    {
        InitializeComponent();
    }

    public udcComboForUI(IContainer container)
    {
        container.Add(this);
        InitializeComponent();
    }
   
    public void ucDisplayBaseProducts()
    {
        daBaseProducts BaseProducts = new daBaseProducts();
        this.ucDisplayDataTable(BaseProducts.PopulateForUiList());
    }
   
    public void ucDisplayPictures()
    {
        daPictures Pictures = new daPictures();
        this.ucDisplayDataTable(Pictures.PopulateForUiList());
    }
   
    public void ucDisplaySales()
    {
        daSales Sales = new daSales();
        this.ucDisplayDataTable(Sales.PopulateForUiList());
    }
   
    public void ucDisplaySaleItems()
    {
        daSaleItems SaleItems = new daSaleItems();
        this.ucDisplayDataTable(SaleItems.PopulateForUiList());
    }
   
    public void ucDisplayShopProducts()
    {
        daShopProducts ShopProducts = new daShopProducts();
        this.ucDisplayDataTable(ShopProducts.PopulateForUiList());
    }
   
    public void ucDisplayShopProductComponents()
    {
        daShopProductComponents ShopProductComponents = new daShopProductComponents();
        this.ucDisplayDataTable(ShopProductComponents.PopulateForUiList());
    }
   
    public void ucDisplayShopProductTypes()
    {
        daShopProductTypes ShopProductTypes = new daShopProductTypes();
        this.ucDisplayDataTable(ShopProductTypes.PopulateForUiList());
    }
   
    public void ucDisplaySuppliers()
    {
        daSuppliers Suppliers = new daSuppliers();
        this.ucDisplayDataTable(Suppliers.PopulateForUiList());
    }
   }