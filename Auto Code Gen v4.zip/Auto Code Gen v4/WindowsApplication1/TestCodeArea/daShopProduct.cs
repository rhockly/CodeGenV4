using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daShopProduct 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private int _nIdShopProduct;
	private string _sName;
	private int _nPictureId;
	private decimal _dPrice;
	private int _nShopProductId;
	private decimal _dTotal;
	private decimal _dVat;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   IdShopProduct
    //   Description :   Get/Set property for IdShopProduct.
    //--------------------------------------------------------------------------
    public int IdShopProduct
    {
        get
        {
            return _nIdShopProduct;
        }
        set
        {
            _nIdShopProduct = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Name
    //   Description :   Get/Set property for Name.
    //--------------------------------------------------------------------------
    public string Name
    {
        get
        {
            return _sName;
        }
        set
        {
            _sName = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   PictureId
    //   Description :   Get/Set property for PictureId.
    //--------------------------------------------------------------------------
    public int PictureId
    {
        get
        {
            return _nPictureId;
        }
        set
        {
            _nPictureId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Price
    //   Description :   Get/Set property for Price.
    //--------------------------------------------------------------------------
    public decimal Price
    {
        get
        {
            return _dPrice;
        }
        set
        {
            _dPrice = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   ShopProductId
    //   Description :   Get/Set property for ShopProductId.
    //--------------------------------------------------------------------------
    public int ShopProductId
    {
        get
        {
            return _nShopProductId;
        }
        set
        {
            _nShopProductId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Total
    //   Description :   Get/Set property for Total.
    //--------------------------------------------------------------------------
    public decimal Total
    {
        get
        {
            return _dTotal;
        }
        set
        {
            _dTotal = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Vat
    //   Description :   Get/Set property for Vat.
    //--------------------------------------------------------------------------
    public decimal Vat
    {
        get
        {
            return _dVat;
        }
        set
        {
            _dVat = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdShopProduct
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdShopProduct)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdShopProduct", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdShopProduct;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblShopProduct", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdShopProduct", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdShopProduct;
            colParamList.Add(prmID);
            
            //Update Name field
            prmParam = new SqlParameter("@Name", SqlDbType.VarChar, 255);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sName;
            colParamList.Add(prmParam);
            //Update PictureId field
            prmParam = new SqlParameter("@PictureId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nPictureId;
            colParamList.Add(prmParam);
            //Update Price field
            prmParam = new SqlParameter("@Price", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dPrice;
            colParamList.Add(prmParam);
            //Update ShopProductId field
            prmParam = new SqlParameter("@ShopProductId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nShopProductId;
            colParamList.Add(prmParam);
            //Update Total field
            prmParam = new SqlParameter("@Total", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dTotal;
            colParamList.Add(prmParam);
            //Update Vat field
            prmParam = new SqlParameter("@Vat", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dVat;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblShopProduct", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdShopProduct == 0)
                {
                    //Get the new record Id
                    _nIdShopProduct = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdShopProduct", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdShopProduct;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblShopProduct", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdShopProduct"))) 
		{
			_nIdShopProduct = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdShopProduct"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Name"))) 
		{
			_sName = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Name"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("PictureId"))) 
		{
			_nPictureId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("PictureId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Price"))) 
		{
			_dPrice = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Price"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ShopProductId"))) 
		{
			_nShopProductId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("ShopProductId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Total"))) 
		{
			_dTotal = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Total"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Vat"))) 
		{
			_dVat = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Vat"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daShopProducts : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daShopProduct Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daShopProduct odaShopProduct;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProducts");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaShopProduct = new daShopProduct();
                odaShopProduct.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaShopProduct);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProducts");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
