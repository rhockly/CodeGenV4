using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmSaleItem
{
    private int _id = 0;
    private daSaleItem _SaleItem;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;
			udcComboForUIShopProductId.ucDisplayShopProducts();
			udcComboForUISaleId.ucDisplaySales();

        if (_id != 0)
        {
            _SaleItem = new daSaleItem();
            _SaleItem.Populate(_id);
			txtPricePerUnit.Text = _SaleItem.PricePerUnit.ToString();
			txtVat.Text = _SaleItem.Vat.ToString();
			txtQuantity.Text = _SaleItem.Quantity.ToString();
			udcComboForUIShopProductId.ucSetId(_SaleItem.ShopProductId.ToString());
			udcComboForUISaleId.ucSetId(_SaleItem.SaleId.ToString());
			txtTotal.Text = _SaleItem.Total.ToString();
			txtSubtotal.Text = _SaleItem.Subtotal.ToString();

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _SaleItem = new daSaleItem();
            _SaleItem.Ts = DateTime.Now;
        }

			_SaleItem.PricePerUnit = Convert.ToDecimal(txtPricePerUnit.Text);
			_SaleItem.Vat = Convert.ToDecimal(txtVat.Text);
			_SaleItem.Quantity = Convert.ToInt32(txtQuantity.Text);
			_SaleItem.ShopProductId = System.Convert.ToInt32( udcComboForUIShopProductId.ucGetId());
			_SaleItem.SaleId = System.Convert.ToInt32( udcComboForUISaleId.ucGetId());
			_SaleItem.Total = Convert.ToDecimal(txtTotal.Text);
			_SaleItem.Subtotal = Convert.ToDecimal(txtSubtotal.Text);


        eRes = _SaleItem.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtPricePerUnit_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtVat_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtQuantity_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUIShopProductId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUISaleId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtTotal_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtSubtotal_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

