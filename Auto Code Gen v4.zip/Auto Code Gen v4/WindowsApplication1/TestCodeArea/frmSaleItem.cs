using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

public partial class frmSaleItem : Form
{
    public frmSaleItem()
    {
        InitializeComponent();
    }

    public string ValidateControls()
    {
        string ValidationMessage = "";

        if (_Populating)
        {
            return "";
        }

        //Check the values in the text boxes (if required), Here and set ValidationMessage 
        //to a message if incorrect


        if (ValidationMessage == "")
        {
            btnSave.Enabled = true;
            return ValidationMessage;
        }
        else
        {
            UiSupport.DisplayMessage(eSqlreturns.IncorrectDataEntry);
            btnSave.Enabled = false;
            return ValidationMessage;
        }
    }

}
