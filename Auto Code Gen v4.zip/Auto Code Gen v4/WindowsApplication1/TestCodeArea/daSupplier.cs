using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daSupplier 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private string _sAddress;
	private string _sFax;
	private int _nIdSupplier;
	private string _sMainContact;
	private string _sMobile;
	private string _sName;
	private string _sTelephone;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   Address
    //   Description :   Get/Set property for Address.
    //--------------------------------------------------------------------------
    public string Address
    {
        get
        {
            return _sAddress;
        }
        set
        {
            _sAddress = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Fax
    //   Description :   Get/Set property for Fax.
    //--------------------------------------------------------------------------
    public string Fax
    {
        get
        {
            return _sFax;
        }
        set
        {
            _sFax = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   IdSupplier
    //   Description :   Get/Set property for IdSupplier.
    //--------------------------------------------------------------------------
    public int IdSupplier
    {
        get
        {
            return _nIdSupplier;
        }
        set
        {
            _nIdSupplier = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   MainContact
    //   Description :   Get/Set property for MainContact.
    //--------------------------------------------------------------------------
    public string MainContact
    {
        get
        {
            return _sMainContact;
        }
        set
        {
            _sMainContact = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Mobile
    //   Description :   Get/Set property for Mobile.
    //--------------------------------------------------------------------------
    public string Mobile
    {
        get
        {
            return _sMobile;
        }
        set
        {
            _sMobile = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Name
    //   Description :   Get/Set property for Name.
    //--------------------------------------------------------------------------
    public string Name
    {
        get
        {
            return _sName;
        }
        set
        {
            _sName = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Telephone
    //   Description :   Get/Set property for Telephone.
    //--------------------------------------------------------------------------
    public string Telephone
    {
        get
        {
            return _sTelephone;
        }
        set
        {
            _sTelephone = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdSupplier
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdSupplier)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdSupplier", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdSupplier;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblSupplier", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdSupplier", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdSupplier;
            colParamList.Add(prmID);
            
            //Update Address field
            prmParam = new SqlParameter("@Address", SqlDbType.VarChar, 50);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sAddress;
            colParamList.Add(prmParam);
            //Update Fax field
            prmParam = new SqlParameter("@Fax", SqlDbType.VarChar, 50);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sFax;
            colParamList.Add(prmParam);
            //Update MainContact field
            prmParam = new SqlParameter("@MainContact", SqlDbType.VarChar, 50);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sMainContact;
            colParamList.Add(prmParam);
            //Update Mobile field
            prmParam = new SqlParameter("@Mobile", SqlDbType.VarChar, 50);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sMobile;
            colParamList.Add(prmParam);
            //Update Name field
            prmParam = new SqlParameter("@Name", SqlDbType.VarChar, 255);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sName;
            colParamList.Add(prmParam);
            //Update Telephone field
            prmParam = new SqlParameter("@Telephone", SqlDbType.VarChar, 50);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sTelephone;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblSupplier", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdSupplier == 0)
                {
                    //Get the new record Id
                    _nIdSupplier = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdSupplier", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdSupplier;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblSupplier", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Address"))) 
		{
			_sAddress = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Address"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Fax"))) 
		{
			_sFax = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Fax"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdSupplier"))) 
		{
			_nIdSupplier = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdSupplier"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("MainContact"))) 
		{
			_sMainContact = prdrDataReader.GetString(prdrDataReader.GetOrdinal("MainContact"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Mobile"))) 
		{
			_sMobile = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Mobile"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Name"))) 
		{
			_sName = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Name"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Telephone"))) 
		{
			_sTelephone = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Telephone"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daSuppliers : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daSupplier Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daSupplier odaSupplier;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSuppliers");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaSupplier = new daSupplier();
                odaSupplier.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaSupplier);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSuppliers");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
