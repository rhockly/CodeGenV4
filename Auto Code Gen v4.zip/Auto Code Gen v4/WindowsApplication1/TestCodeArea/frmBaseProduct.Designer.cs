
    partial class frmBaseProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.lblName = new System.Windows.Forms.Label();
		this.txtUnitsInCase = new System.Windows.Forms.TextBox();
		this.lblSupplierId = new System.Windows.Forms.Label();
		this.txtWeightPerUnit = new System.Windows.Forms.TextBox();
		this.lblWeightPerUnit = new System.Windows.Forms.Label();
		this.txtName = new System.Windows.Forms.TextBox();
		this.lblUnitsInCase = new System.Windows.Forms.Label();
		this.txtPricePerCase = new System.Windows.Forms.TextBox();
		this.udcComboForUISupplierId = new udcComboForUI();
		this.lblPricePerCase = new System.Windows.Forms.Label();

		this.SuspendLayout();
		// 
		// lblName
		// 
		this.lblName.AutoSize = true;
		this.lblName.Location = new System.Drawing.Point(20, 23);
		this.lblName.Name = "lblName";
		this.lblName.Size = new System.Drawing.Size(100, 20);
		this.lblName.Name = "lblName";
		this.lblName.Text = "Name";
		// 
		// txtUnitsInCase
		// 
		this.txtUnitsInCase.Location = new System.Drawing.Point(150, 80);
		this.txtUnitsInCase.MaxLength = 0;
		this.txtUnitsInCase.Name = "txtUnitsInCase";
		this.txtUnitsInCase.Size = new System.Drawing.Size(100, 20);
		this.txtUnitsInCase.TabIndex = 4;
		this.txtUnitsInCase.TextChanged += new System.EventHandler(this.txtUnitsInCase_TextChanged);		// 
		// lblSupplierId
		// 
		this.lblSupplierId.AutoSize = true;
		this.lblSupplierId.Location = new System.Drawing.Point(20, 63);
		this.lblSupplierId.Name = "lblSupplierId";
		this.lblSupplierId.Size = new System.Drawing.Size(100, 20);
		this.lblSupplierId.Name = "lblSupplierId";
		this.lblSupplierId.Text = "Supplier";
		// 
		// txtWeightPerUnit
		// 
		this.txtWeightPerUnit.Location = new System.Drawing.Point(150, 100);
		this.txtWeightPerUnit.MaxLength = 0;
		this.txtWeightPerUnit.Name = "txtWeightPerUnit";
		this.txtWeightPerUnit.Size = new System.Drawing.Size(100, 20);
		this.txtWeightPerUnit.TabIndex = 5;
		this.txtWeightPerUnit.TextChanged += new System.EventHandler(this.txtWeightPerUnit_TextChanged);		// 
		// lblWeightPerUnit
		// 
		this.lblWeightPerUnit.AutoSize = true;
		this.lblWeightPerUnit.Location = new System.Drawing.Point(20, 103);
		this.lblWeightPerUnit.Name = "lblWeightPerUnit";
		this.lblWeightPerUnit.Size = new System.Drawing.Size(100, 20);
		this.lblWeightPerUnit.Name = "lblWeightPerUnit";
		this.lblWeightPerUnit.Text = "Weight Per Unit";
		// 
		// txtName
		// 
		this.txtName.Location = new System.Drawing.Point(150, 20);
		this.txtName.MaxLength = 255;
		this.txtName.Name = "txtName";
		this.txtName.Size = new System.Drawing.Size(100, 20);
		this.txtName.TabIndex = 1;
		this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);		// 
		// lblUnitsInCase
		// 
		this.lblUnitsInCase.AutoSize = true;
		this.lblUnitsInCase.Location = new System.Drawing.Point(20, 83);
		this.lblUnitsInCase.Name = "lblUnitsInCase";
		this.lblUnitsInCase.Size = new System.Drawing.Size(100, 20);
		this.lblUnitsInCase.Name = "lblUnitsInCase";
		this.lblUnitsInCase.Text = "Units In Case";
		// 
		// txtPricePerCase
		// 
		this.txtPricePerCase.Location = new System.Drawing.Point(150, 40);
		this.txtPricePerCase.MaxLength = 0;
		this.txtPricePerCase.Name = "txtPricePerCase";
		this.txtPricePerCase.Size = new System.Drawing.Size(100, 20);
		this.txtPricePerCase.TabIndex = 2;
		this.txtPricePerCase.TextChanged += new System.EventHandler(this.txtPricePerCase_TextChanged);		// 
		// udcComboForUISupplierId
		// 
		this.udcComboForUISupplierId.Location = new System.Drawing.Point(150, 60);
		this.udcComboForUISupplierId.MaxLength = 0;
		this.udcComboForUISupplierId.Name = "udcComboForUISupplierId";
		this.udcComboForUISupplierId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUISupplierId.TabIndex = 3;
		this.udcComboForUISupplierId.SelectedValueChanged += new System.EventHandler(this.udcComboForUISupplierId_SelectedValueChanged);		// 
		// lblPricePerCase
		// 
		this.lblPricePerCase.AutoSize = true;
		this.lblPricePerCase.Location = new System.Drawing.Point(20, 43);
		this.lblPricePerCase.Name = "lblPricePerCase";
		this.lblPricePerCase.Size = new System.Drawing.Size(100, 20);
		this.lblPricePerCase.Name = "lblPricePerCase";
		this.lblPricePerCase.Text = "Price Per Case";

            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmBaseProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblName);
this.Controls.Add(this.txtUnitsInCase);
this.Controls.Add(this.lblSupplierId);
this.Controls.Add(this.txtWeightPerUnit);
this.Controls.Add(this.lblWeightPerUnit);
this.Controls.Add(this.txtName);
this.Controls.Add(this.lblUnitsInCase);
this.Controls.Add(this.txtPricePerCase);
this.Controls.Add(this.udcComboForUISupplierId);
this.Controls.Add(this.lblPricePerCase);
this.Name = "frmBaseProduct";
            this.Text = "BaseProduct";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private System.Windows.Forms.Label lblName;
	private System.Windows.Forms.TextBox txtUnitsInCase;
	private System.Windows.Forms.Label lblSupplierId;
	private System.Windows.Forms.TextBox txtWeightPerUnit;
	private System.Windows.Forms.Label lblWeightPerUnit;
	private System.Windows.Forms.TextBox txtName;
	private System.Windows.Forms.Label lblUnitsInCase;
	private System.Windows.Forms.TextBox txtPricePerCase;
	private udcComboForUI udcComboForUISupplierId;
	private System.Windows.Forms.Label lblPricePerCase;
}