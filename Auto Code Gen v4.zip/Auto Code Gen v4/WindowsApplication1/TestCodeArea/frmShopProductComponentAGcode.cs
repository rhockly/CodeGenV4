using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmShopProductComponent
{
    private int _id = 0;
    private daShopProductComponent _ShopProductComponent;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;
			udcComboForUIBaseProductId.ucDisplayBaseProducts();
			udcComboForUIShopProductId.ucDisplayShopProducts();

        if (_id != 0)
        {
            _ShopProductComponent = new daShopProductComponent();
            _ShopProductComponent.Populate(_id);
			udcComboForUIBaseProductId.ucSetId(_ShopProductComponent.BaseProductId.ToString());
			txtUnitsUsed.Text = _ShopProductComponent.UnitsUsed.ToString();
			txtWeightUsed.Text = _ShopProductComponent.WeightUsed.ToString();
			udcComboForUIShopProductId.ucSetId(_ShopProductComponent.ShopProductId.ToString());

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _ShopProductComponent = new daShopProductComponent();
            _ShopProductComponent.Ts = DateTime.Now;
        }

			_ShopProductComponent.BaseProductId = System.Convert.ToInt32( udcComboForUIBaseProductId.ucGetId());
			_ShopProductComponent.UnitsUsed = Convert.ToDecimal(txtUnitsUsed.Text);
			_ShopProductComponent.WeightUsed = Convert.ToDecimal(txtWeightUsed.Text);
			_ShopProductComponent.ShopProductId = System.Convert.ToInt32( udcComboForUIShopProductId.ucGetId());


        eRes = _ShopProductComponent.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void udcComboForUIBaseProductId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtUnitsUsed_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtWeightUsed_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUIShopProductId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

