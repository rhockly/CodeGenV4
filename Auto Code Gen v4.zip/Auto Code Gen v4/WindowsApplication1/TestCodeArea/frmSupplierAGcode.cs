using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmSupplier
{
    private int _id = 0;
    private daSupplier _Supplier;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;

        if (_id != 0)
        {
            _Supplier = new daSupplier();
            _Supplier.Populate(_id);
			txtAddress.Text = _Supplier.Address.ToString();
			txtMainContact.Text = _Supplier.MainContact.ToString();
			txtTelephone.Text = _Supplier.Telephone.ToString();
			txtMobile.Text = _Supplier.Mobile.ToString();
			txtName.Text = _Supplier.Name.ToString();
			txtFax.Text = _Supplier.Fax.ToString();

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _Supplier = new daSupplier();
            _Supplier.Ts = DateTime.Now;
        }

			_Supplier.Address = txtAddress.Text;
			_Supplier.MainContact = txtMainContact.Text;
			_Supplier.Telephone = txtTelephone.Text;
			_Supplier.Mobile = txtMobile.Text;
			_Supplier.Name = txtName.Text;
			_Supplier.Fax = txtFax.Text;


        eRes = _Supplier.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtAddress_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtMainContact_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtTelephone_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtMobile_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtFax_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

