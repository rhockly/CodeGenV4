
    partial class frmSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.txtVat = new System.Windows.Forms.TextBox();
		this.lblSubTotal = new System.Windows.Forms.Label();
		this.lblTotal = new System.Windows.Forms.Label();
		this.txtTotal = new System.Windows.Forms.TextBox();
		this.lblCashRecieved = new System.Windows.Forms.Label();
		this.lblTimeOfSale = new System.Windows.Forms.Label();
		this.txtSubTotal = new System.Windows.Forms.TextBox();
		this.txtCashRecieved = new System.Windows.Forms.TextBox();
		this.txtChangeGiven = new System.Windows.Forms.TextBox();
		this.txtTimeOfSale = new System.Windows.Forms.TextBox();
		this.lblVat = new System.Windows.Forms.Label();
		this.lblChangeGiven = new System.Windows.Forms.Label();

		this.SuspendLayout();
		// 
		// txtVat
		// 
		this.txtVat.Location = new System.Drawing.Point(150, 120);
		this.txtVat.MaxLength = 0;
		this.txtVat.Name = "txtVat";
		this.txtVat.Size = new System.Drawing.Size(100, 20);
		this.txtVat.TabIndex = 6;
		this.txtVat.TextChanged += new System.EventHandler(this.txtVat_TextChanged);		// 
		// lblSubTotal
		// 
		this.lblSubTotal.AutoSize = true;
		this.lblSubTotal.Location = new System.Drawing.Point(20, 63);
		this.lblSubTotal.Name = "lblSubTotal";
		this.lblSubTotal.Size = new System.Drawing.Size(100, 20);
		this.lblSubTotal.Name = "lblSubTotal";
		this.lblSubTotal.Text = "Sub Total";
		// 
		// lblTotal
		// 
		this.lblTotal.AutoSize = true;
		this.lblTotal.Location = new System.Drawing.Point(20, 103);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Size = new System.Drawing.Size(100, 20);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Text = "Total";
		// 
		// txtTotal
		// 
		this.txtTotal.Location = new System.Drawing.Point(150, 100);
		this.txtTotal.MaxLength = 0;
		this.txtTotal.Name = "txtTotal";
		this.txtTotal.Size = new System.Drawing.Size(100, 20);
		this.txtTotal.TabIndex = 5;
		this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);		// 
		// lblCashRecieved
		// 
		this.lblCashRecieved.AutoSize = true;
		this.lblCashRecieved.Location = new System.Drawing.Point(20, 23);
		this.lblCashRecieved.Name = "lblCashRecieved";
		this.lblCashRecieved.Size = new System.Drawing.Size(100, 20);
		this.lblCashRecieved.Name = "lblCashRecieved";
		this.lblCashRecieved.Text = "Cash Recieved";
		// 
		// lblTimeOfSale
		// 
		this.lblTimeOfSale.AutoSize = true;
		this.lblTimeOfSale.Location = new System.Drawing.Point(20, 83);
		this.lblTimeOfSale.Name = "lblTimeOfSale";
		this.lblTimeOfSale.Size = new System.Drawing.Size(100, 20);
		this.lblTimeOfSale.Name = "lblTimeOfSale";
		this.lblTimeOfSale.Text = "Time Of Sale";
		// 
		// txtSubTotal
		// 
		this.txtSubTotal.Location = new System.Drawing.Point(150, 60);
		this.txtSubTotal.MaxLength = 0;
		this.txtSubTotal.Name = "txtSubTotal";
		this.txtSubTotal.Size = new System.Drawing.Size(100, 20);
		this.txtSubTotal.TabIndex = 3;
		this.txtSubTotal.TextChanged += new System.EventHandler(this.txtSubTotal_TextChanged);		// 
		// txtCashRecieved
		// 
		this.txtCashRecieved.Location = new System.Drawing.Point(150, 20);
		this.txtCashRecieved.MaxLength = 0;
		this.txtCashRecieved.Name = "txtCashRecieved";
		this.txtCashRecieved.Size = new System.Drawing.Size(100, 20);
		this.txtCashRecieved.TabIndex = 1;
		this.txtCashRecieved.TextChanged += new System.EventHandler(this.txtCashRecieved_TextChanged);		// 
		// txtChangeGiven
		// 
		this.txtChangeGiven.Location = new System.Drawing.Point(150, 40);
		this.txtChangeGiven.MaxLength = 0;
		this.txtChangeGiven.Name = "txtChangeGiven";
		this.txtChangeGiven.Size = new System.Drawing.Size(100, 20);
		this.txtChangeGiven.TabIndex = 2;
		this.txtChangeGiven.TextChanged += new System.EventHandler(this.txtChangeGiven_TextChanged);		// 
		// txtTimeOfSale
		// 
		this.txtTimeOfSale.Location = new System.Drawing.Point(150, 80);
		this.txtTimeOfSale.MaxLength = 0;
		this.txtTimeOfSale.Name = "txtTimeOfSale";
		this.txtTimeOfSale.Size = new System.Drawing.Size(100, 20);
		this.txtTimeOfSale.TabIndex = 4;
		this.txtTimeOfSale.TextChanged += new System.EventHandler(this.txtTimeOfSale_TextChanged);		// 
		// lblVat
		// 
		this.lblVat.AutoSize = true;
		this.lblVat.Location = new System.Drawing.Point(20, 123);
		this.lblVat.Name = "lblVat";
		this.lblVat.Size = new System.Drawing.Size(100, 20);
		this.lblVat.Name = "lblVat";
		this.lblVat.Text = "Vat";
		// 
		// lblChangeGiven
		// 
		this.lblChangeGiven.AutoSize = true;
		this.lblChangeGiven.Location = new System.Drawing.Point(20, 43);
		this.lblChangeGiven.Name = "lblChangeGiven";
		this.lblChangeGiven.Size = new System.Drawing.Size(100, 20);
		this.lblChangeGiven.Name = "lblChangeGiven";
		this.lblChangeGiven.Text = "Change Given";

            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtVat);
this.Controls.Add(this.lblSubTotal);
this.Controls.Add(this.lblTotal);
this.Controls.Add(this.txtTotal);
this.Controls.Add(this.lblCashRecieved);
this.Controls.Add(this.lblTimeOfSale);
this.Controls.Add(this.txtSubTotal);
this.Controls.Add(this.txtCashRecieved);
this.Controls.Add(this.txtChangeGiven);
this.Controls.Add(this.txtTimeOfSale);
this.Controls.Add(this.lblVat);
this.Controls.Add(this.lblChangeGiven);
this.Name = "frmSale";
            this.Text = "Sale";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private System.Windows.Forms.TextBox txtVat;
	private System.Windows.Forms.Label lblSubTotal;
	private System.Windows.Forms.Label lblTotal;
	private System.Windows.Forms.TextBox txtTotal;
	private System.Windows.Forms.Label lblCashRecieved;
	private System.Windows.Forms.Label lblTimeOfSale;
	private System.Windows.Forms.TextBox txtSubTotal;
	private System.Windows.Forms.TextBox txtCashRecieved;
	private System.Windows.Forms.TextBox txtChangeGiven;
	private System.Windows.Forms.TextBox txtTimeOfSale;
	private System.Windows.Forms.Label lblVat;
	private System.Windows.Forms.Label lblChangeGiven;
}