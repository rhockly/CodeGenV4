using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daSaleItem 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private int _nIdSaleItem;
	private decimal _dPricePerUnit;
	private int _nQuantity;
	private int _nSaleId;
	private int _nShopProductId;
	private decimal _dSubtotal;
	private decimal _dTotal;
	private decimal _dVat;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   IdSaleItem
    //   Description :   Get/Set property for IdSaleItem.
    //--------------------------------------------------------------------------
    public int IdSaleItem
    {
        get
        {
            return _nIdSaleItem;
        }
        set
        {
            _nIdSaleItem = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   PricePerUnit
    //   Description :   Get/Set property for PricePerUnit.
    //--------------------------------------------------------------------------
    public decimal PricePerUnit
    {
        get
        {
            return _dPricePerUnit;
        }
        set
        {
            _dPricePerUnit = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Quantity
    //   Description :   Get/Set property for Quantity.
    //--------------------------------------------------------------------------
    public int Quantity
    {
        get
        {
            return _nQuantity;
        }
        set
        {
            _nQuantity = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   SaleId
    //   Description :   Get/Set property for SaleId.
    //--------------------------------------------------------------------------
    public int SaleId
    {
        get
        {
            return _nSaleId;
        }
        set
        {
            _nSaleId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   ShopProductId
    //   Description :   Get/Set property for ShopProductId.
    //--------------------------------------------------------------------------
    public int ShopProductId
    {
        get
        {
            return _nShopProductId;
        }
        set
        {
            _nShopProductId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Subtotal
    //   Description :   Get/Set property for Subtotal.
    //--------------------------------------------------------------------------
    public decimal Subtotal
    {
        get
        {
            return _dSubtotal;
        }
        set
        {
            _dSubtotal = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Total
    //   Description :   Get/Set property for Total.
    //--------------------------------------------------------------------------
    public decimal Total
    {
        get
        {
            return _dTotal;
        }
        set
        {
            _dTotal = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Vat
    //   Description :   Get/Set property for Vat.
    //--------------------------------------------------------------------------
    public decimal Vat
    {
        get
        {
            return _dVat;
        }
        set
        {
            _dVat = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdSaleItem
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdSaleItem)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdSaleItem", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdSaleItem;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblSaleItem", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdSaleItem", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdSaleItem;
            colParamList.Add(prmID);
            
            //Update PricePerUnit field
            prmParam = new SqlParameter("@PricePerUnit", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dPricePerUnit;
            colParamList.Add(prmParam);
            //Update Quantity field
            prmParam = new SqlParameter("@Quantity", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nQuantity;
            colParamList.Add(prmParam);
            //Update SaleId field
            prmParam = new SqlParameter("@SaleId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nSaleId;
            colParamList.Add(prmParam);
            //Update ShopProductId field
            prmParam = new SqlParameter("@ShopProductId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nShopProductId;
            colParamList.Add(prmParam);
            //Update Subtotal field
            prmParam = new SqlParameter("@Subtotal", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dSubtotal;
            colParamList.Add(prmParam);
            //Update Total field
            prmParam = new SqlParameter("@Total", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dTotal;
            colParamList.Add(prmParam);
            //Update Vat field
            prmParam = new SqlParameter("@Vat", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dVat;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblSaleItem", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdSaleItem == 0)
                {
                    //Get the new record Id
                    _nIdSaleItem = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdSaleItem", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdSaleItem;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblSaleItem", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdSaleItem"))) 
		{
			_nIdSaleItem = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdSaleItem"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("PricePerUnit"))) 
		{
			_dPricePerUnit = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("PricePerUnit"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Quantity"))) 
		{
			_nQuantity = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("Quantity"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("SaleId"))) 
		{
			_nSaleId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("SaleId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ShopProductId"))) 
		{
			_nShopProductId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("ShopProductId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Subtotal"))) 
		{
			_dSubtotal = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Subtotal"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Total"))) 
		{
			_dTotal = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Total"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Vat"))) 
		{
			_dVat = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Vat"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daSaleItems : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daSaleItem Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daSaleItem odaSaleItem;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSaleItems");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaSaleItem = new daSaleItem();
                odaSaleItem.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaSaleItem);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSaleItems");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
