using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daSale 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private decimal _dCashRecieved;
	private decimal _dChangeGiven;
	private int _nIdSale;
	private decimal _dSubTotal;
	private DateTime _dtTimeOfSale;
	private decimal _dTotal;
	private decimal _dVat;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   CashRecieved
    //   Description :   Get/Set property for CashRecieved.
    //--------------------------------------------------------------------------
    public decimal CashRecieved
    {
        get
        {
            return _dCashRecieved;
        }
        set
        {
            _dCashRecieved = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   ChangeGiven
    //   Description :   Get/Set property for ChangeGiven.
    //--------------------------------------------------------------------------
    public decimal ChangeGiven
    {
        get
        {
            return _dChangeGiven;
        }
        set
        {
            _dChangeGiven = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   IdSale
    //   Description :   Get/Set property for IdSale.
    //--------------------------------------------------------------------------
    public int IdSale
    {
        get
        {
            return _nIdSale;
        }
        set
        {
            _nIdSale = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   SubTotal
    //   Description :   Get/Set property for SubTotal.
    //--------------------------------------------------------------------------
    public decimal SubTotal
    {
        get
        {
            return _dSubTotal;
        }
        set
        {
            _dSubTotal = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   TimeOfSale
    //   Description :   Get/Set property for TimeOfSale.
    //--------------------------------------------------------------------------
    public DateTime TimeOfSale
    {
        get
        {
            return _dtTimeOfSale;
        }
        set
        {
            _dtTimeOfSale = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Total
    //   Description :   Get/Set property for Total.
    //--------------------------------------------------------------------------
    public decimal Total
    {
        get
        {
            return _dTotal;
        }
        set
        {
            _dTotal = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Vat
    //   Description :   Get/Set property for Vat.
    //--------------------------------------------------------------------------
    public decimal Vat
    {
        get
        {
            return _dVat;
        }
        set
        {
            _dVat = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdSale
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdSale)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdSale", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdSale;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblSale", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdSale", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdSale;
            colParamList.Add(prmID);
            
            //Update CashRecieved field
            prmParam = new SqlParameter("@CashRecieved", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dCashRecieved;
            colParamList.Add(prmParam);
            //Update ChangeGiven field
            prmParam = new SqlParameter("@ChangeGiven", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dChangeGiven;
            colParamList.Add(prmParam);
            //Update SubTotal field
            prmParam = new SqlParameter("@SubTotal", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dSubTotal;
            colParamList.Add(prmParam);
            //Update TimeOfSale field
            prmParam = new SqlParameter("@TimeOfSale", SqlDbType.DateTime);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dtTimeOfSale;
            colParamList.Add(prmParam);
            //Update Total field
            prmParam = new SqlParameter("@Total", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dTotal;
            colParamList.Add(prmParam);
            //Update Vat field
            prmParam = new SqlParameter("@Vat", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dVat;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblSale", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdSale == 0)
                {
                    //Get the new record Id
                    _nIdSale = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdSale", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdSale;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblSale", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("CashRecieved"))) 
		{
			_dCashRecieved = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("CashRecieved"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ChangeGiven"))) 
		{
			_dChangeGiven = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("ChangeGiven"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdSale"))) 
		{
			_nIdSale = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdSale"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("SubTotal"))) 
		{
			_dSubTotal = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("SubTotal"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("TimeOfSale"))) 
		{
			_dtTimeOfSale = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("TimeOfSale"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Total"))) 
		{
			_dTotal = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Total"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Vat"))) 
		{
			_dVat = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("Vat"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daSales : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daSale Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daSale odaSale;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSales");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaSale = new daSale();
                odaSale.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaSale);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblSales");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
