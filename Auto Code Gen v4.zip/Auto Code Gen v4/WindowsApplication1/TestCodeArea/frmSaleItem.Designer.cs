
    partial class frmSaleItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.lblPricePerUnit = new System.Windows.Forms.Label();
		this.lblTotal = new System.Windows.Forms.Label();
		this.txtPricePerUnit = new System.Windows.Forms.TextBox();
		this.lblSubtotal = new System.Windows.Forms.Label();
		this.lblShopProductId = new System.Windows.Forms.Label();
		this.lblSaleId = new System.Windows.Forms.Label();
		this.txtVat = new System.Windows.Forms.TextBox();
		this.txtQuantity = new System.Windows.Forms.TextBox();
		this.lblVat = new System.Windows.Forms.Label();
		this.udcComboForUIShopProductId = new udcComboForUI();
		this.udcComboForUISaleId = new udcComboForUI();
		this.lblQuantity = new System.Windows.Forms.Label();
		this.txtTotal = new System.Windows.Forms.TextBox();
		this.txtSubtotal = new System.Windows.Forms.TextBox();

		this.SuspendLayout();
		// 
		// lblPricePerUnit
		// 
		this.lblPricePerUnit.AutoSize = true;
		this.lblPricePerUnit.Location = new System.Drawing.Point(20, 23);
		this.lblPricePerUnit.Name = "lblPricePerUnit";
		this.lblPricePerUnit.Size = new System.Drawing.Size(100, 20);
		this.lblPricePerUnit.Name = "lblPricePerUnit";
		this.lblPricePerUnit.Text = "Price Per Unit";
		// 
		// lblTotal
		// 
		this.lblTotal.AutoSize = true;
		this.lblTotal.Location = new System.Drawing.Point(20, 123);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Size = new System.Drawing.Size(100, 20);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Text = "Total";
		// 
		// txtPricePerUnit
		// 
		this.txtPricePerUnit.Location = new System.Drawing.Point(150, 20);
		this.txtPricePerUnit.MaxLength = 0;
		this.txtPricePerUnit.Name = "txtPricePerUnit";
		this.txtPricePerUnit.Size = new System.Drawing.Size(100, 20);
		this.txtPricePerUnit.TabIndex = 1;
		this.txtPricePerUnit.TextChanged += new System.EventHandler(this.txtPricePerUnit_TextChanged);		// 
		// lblSubtotal
		// 
		this.lblSubtotal.AutoSize = true;
		this.lblSubtotal.Location = new System.Drawing.Point(20, 103);
		this.lblSubtotal.Name = "lblSubtotal";
		this.lblSubtotal.Size = new System.Drawing.Size(100, 20);
		this.lblSubtotal.Name = "lblSubtotal";
		this.lblSubtotal.Text = "Subtotal";
		// 
		// lblShopProductId
		// 
		this.lblShopProductId.AutoSize = true;
		this.lblShopProductId.Location = new System.Drawing.Point(20, 83);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Size = new System.Drawing.Size(100, 20);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Text = "Shop Product";
		// 
		// lblSaleId
		// 
		this.lblSaleId.AutoSize = true;
		this.lblSaleId.Location = new System.Drawing.Point(20, 63);
		this.lblSaleId.Name = "lblSaleId";
		this.lblSaleId.Size = new System.Drawing.Size(100, 20);
		this.lblSaleId.Name = "lblSaleId";
		this.lblSaleId.Text = "Sale";
		// 
		// txtVat
		// 
		this.txtVat.Location = new System.Drawing.Point(150, 140);
		this.txtVat.MaxLength = 0;
		this.txtVat.Name = "txtVat";
		this.txtVat.Size = new System.Drawing.Size(100, 20);
		this.txtVat.TabIndex = 7;
		this.txtVat.TextChanged += new System.EventHandler(this.txtVat_TextChanged);		// 
		// txtQuantity
		// 
		this.txtQuantity.Location = new System.Drawing.Point(150, 40);
		this.txtQuantity.MaxLength = 0;
		this.txtQuantity.Name = "txtQuantity";
		this.txtQuantity.Size = new System.Drawing.Size(100, 20);
		this.txtQuantity.TabIndex = 2;
		this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged);		// 
		// lblVat
		// 
		this.lblVat.AutoSize = true;
		this.lblVat.Location = new System.Drawing.Point(20, 143);
		this.lblVat.Name = "lblVat";
		this.lblVat.Size = new System.Drawing.Size(100, 20);
		this.lblVat.Name = "lblVat";
		this.lblVat.Text = "Vat";
		// 
		// udcComboForUIShopProductId
		// 
		this.udcComboForUIShopProductId.Location = new System.Drawing.Point(150, 80);
		this.udcComboForUIShopProductId.MaxLength = 0;
		this.udcComboForUIShopProductId.Name = "udcComboForUIShopProductId";
		this.udcComboForUIShopProductId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUIShopProductId.TabIndex = 4;
		this.udcComboForUIShopProductId.SelectedValueChanged += new System.EventHandler(this.udcComboForUIShopProductId_SelectedValueChanged);		// 
		// udcComboForUISaleId
		// 
		this.udcComboForUISaleId.Location = new System.Drawing.Point(150, 60);
		this.udcComboForUISaleId.MaxLength = 0;
		this.udcComboForUISaleId.Name = "udcComboForUISaleId";
		this.udcComboForUISaleId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUISaleId.TabIndex = 3;
		this.udcComboForUISaleId.SelectedValueChanged += new System.EventHandler(this.udcComboForUISaleId_SelectedValueChanged);		// 
		// lblQuantity
		// 
		this.lblQuantity.AutoSize = true;
		this.lblQuantity.Location = new System.Drawing.Point(20, 43);
		this.lblQuantity.Name = "lblQuantity";
		this.lblQuantity.Size = new System.Drawing.Size(100, 20);
		this.lblQuantity.Name = "lblQuantity";
		this.lblQuantity.Text = "Quantity";
		// 
		// txtTotal
		// 
		this.txtTotal.Location = new System.Drawing.Point(150, 120);
		this.txtTotal.MaxLength = 0;
		this.txtTotal.Name = "txtTotal";
		this.txtTotal.Size = new System.Drawing.Size(100, 20);
		this.txtTotal.TabIndex = 6;
		this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);		// 
		// txtSubtotal
		// 
		this.txtSubtotal.Location = new System.Drawing.Point(150, 100);
		this.txtSubtotal.MaxLength = 0;
		this.txtSubtotal.Name = "txtSubtotal";
		this.txtSubtotal.Size = new System.Drawing.Size(100, 20);
		this.txtSubtotal.TabIndex = 5;
		this.txtSubtotal.TextChanged += new System.EventHandler(this.txtSubtotal_TextChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmSaleItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblPricePerUnit);
this.Controls.Add(this.lblTotal);
this.Controls.Add(this.txtPricePerUnit);
this.Controls.Add(this.lblSubtotal);
this.Controls.Add(this.lblShopProductId);
this.Controls.Add(this.lblSaleId);
this.Controls.Add(this.txtVat);
this.Controls.Add(this.txtQuantity);
this.Controls.Add(this.lblVat);
this.Controls.Add(this.udcComboForUIShopProductId);
this.Controls.Add(this.udcComboForUISaleId);
this.Controls.Add(this.lblQuantity);
this.Controls.Add(this.txtTotal);
this.Controls.Add(this.txtSubtotal);
this.Name = "frmSaleItem";
            this.Text = "SaleItem";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private System.Windows.Forms.Label lblPricePerUnit;
	private System.Windows.Forms.Label lblTotal;
	private System.Windows.Forms.TextBox txtPricePerUnit;
	private System.Windows.Forms.Label lblSubtotal;
	private System.Windows.Forms.Label lblShopProductId;
	private System.Windows.Forms.Label lblSaleId;
	private System.Windows.Forms.TextBox txtVat;
	private System.Windows.Forms.TextBox txtQuantity;
	private System.Windows.Forms.Label lblVat;
	private udcComboForUI udcComboForUIShopProductId;
	private udcComboForUI udcComboForUISaleId;
	private System.Windows.Forms.Label lblQuantity;
	private System.Windows.Forms.TextBox txtTotal;
	private System.Windows.Forms.TextBox txtSubtotal;
}