using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

    public partial class frmSelectPicture : Form
    {
        private bool _populating;
        private int _currentId=0;
        private int _idIsAtRow = 0;

        public frmSelectPicture()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_currentId==0)
            {
                return;
            }
            eSqlreturns eResult;
            daPicture ClassName = new daPicture();
            if (ClassName.Populate(_currentId)!= eSqlreturns.Success)
            {
                UiSupport.DisplayMessage(eSqlreturns.RecordNotFound);
                PopulateGridAndShowForm();
                return;
            }
            eResult = ClassName.Delete();
            if (eResult == eSqlreturns.Success)
            {
                UiSupport.DisplayMessage(eSqlreturns.DeleteSuccessful);
                PopulateGridAndShowForm();
            }
            else
            {
                UiSupport.DisplayMessage(eResult);
            }
  
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (_currentId == 0)
            {
                return;
            }

            frmPicture frm = new frmPicture();
            frm.FormClosed += new FormClosedEventHandler(ChildFormClosed);
            frm.Populate(_currentId);
            frm.Show();
        }
        
        private void btnNew_Click(object sender, EventArgs e)
        {
            frmPicture frm = new frmPicture();
            frm.FormClosed += new FormClosedEventHandler(ChildFormClosed);
            frm.Populate(0);
            frm.Show();
        }

        private void ChildFormClosed(object sender, FormClosedEventArgs e)
        {
            this.PopulateGridAndShowForm();
        }

        private void SetId()
        {
            
            if (_populating)
            {
                return;
            }
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow dg;

                dg = dataGridView1.SelectedRows[0];
                _currentId = (int)dg.Cells[_idIsAtRow].Value;

            }
            if (dataGridView1.SelectedCells.Count > 0)
            {
                DataGridViewRow dg;
                dg = dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex];
                _currentId = (int)dg.Cells[_idIsAtRow].Value;
            }
            if (_currentId == 0)
            {
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
            {
                btnEdit.Enabled = true;
                btnDelete.Enabled = true;
            }
            this.Text = _currentId.ToString();
           
        }
       
        public void PopulateGridAndShowForm()
        {
            _currentId = 0;
            _populating = true;
            daPictures Pictures = new daPictures();
            DataTable Getinfo;
            
            Getinfo = Pictures.PopulateForUiList();
            dataGridView1.DataSource = Getinfo;
            int RowCount = 0;

            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
               
                if (col.HeaderText.ToLower() == "ts")
                {
                    col.Visible = false;
                }else if (col.HeaderText.Substring(0,2).ToLower() == "id")
                {
                    _idIsAtRow = RowCount;
                    col.Visible = false;
                }
                else
                {
                    col.HeaderText = UiSupport.FormatName(col.HeaderText);
                }
                RowCount += 1;
            }
            _populating = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            SetId();
            
            this.Show();
        }

        private void dataGridView1_MouseUp(object sender, MouseEventArgs e)
        {
            SetId();
        }
    }
