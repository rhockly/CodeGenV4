using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daShopProductComponent 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private int _nBaseProductId;
	private int _nIdShopProductComponent;
	private int _nShopProductId;
	private decimal _dUnitsUsed;
	private decimal _dWeightUsed;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   BaseProductId
    //   Description :   Get/Set property for BaseProductId.
    //--------------------------------------------------------------------------
    public int BaseProductId
    {
        get
        {
            return _nBaseProductId;
        }
        set
        {
            _nBaseProductId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   IdShopProductComponent
    //   Description :   Get/Set property for IdShopProductComponent.
    //--------------------------------------------------------------------------
    public int IdShopProductComponent
    {
        get
        {
            return _nIdShopProductComponent;
        }
        set
        {
            _nIdShopProductComponent = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   ShopProductId
    //   Description :   Get/Set property for ShopProductId.
    //--------------------------------------------------------------------------
    public int ShopProductId
    {
        get
        {
            return _nShopProductId;
        }
        set
        {
            _nShopProductId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   UnitsUsed
    //   Description :   Get/Set property for UnitsUsed.
    //--------------------------------------------------------------------------
    public decimal UnitsUsed
    {
        get
        {
            return _dUnitsUsed;
        }
        set
        {
            _dUnitsUsed = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   WeightUsed
    //   Description :   Get/Set property for WeightUsed.
    //--------------------------------------------------------------------------
    public decimal WeightUsed
    {
        get
        {
            return _dWeightUsed;
        }
        set
        {
            _dWeightUsed = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdShopProductComponent
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdShopProductComponent)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdShopProductComponent", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdShopProductComponent;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblShopProductComponent", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdShopProductComponent", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdShopProductComponent;
            colParamList.Add(prmID);
            
            //Update BaseProductId field
            prmParam = new SqlParameter("@BaseProductId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nBaseProductId;
            colParamList.Add(prmParam);
            //Update ShopProductId field
            prmParam = new SqlParameter("@ShopProductId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nShopProductId;
            colParamList.Add(prmParam);
            //Update UnitsUsed field
            prmParam = new SqlParameter("@UnitsUsed", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dUnitsUsed;
            colParamList.Add(prmParam);
            //Update WeightUsed field
            prmParam = new SqlParameter("@WeightUsed", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dWeightUsed;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblShopProductComponent", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdShopProductComponent == 0)
                {
                    //Get the new record Id
                    _nIdShopProductComponent = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdShopProductComponent", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdShopProductComponent;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblShopProductComponent", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("BaseProductId"))) 
		{
			_nBaseProductId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("BaseProductId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdShopProductComponent"))) 
		{
			_nIdShopProductComponent = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdShopProductComponent"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ShopProductId"))) 
		{
			_nShopProductId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("ShopProductId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("UnitsUsed"))) 
		{
			_dUnitsUsed = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("UnitsUsed"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("WeightUsed"))) 
		{
			_dWeightUsed = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("WeightUsed"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daShopProductComponents : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daShopProductComponent Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daShopProductComponent odaShopProductComponent;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProductComponents");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaShopProductComponent = new daShopProductComponent();
                odaShopProductComponent.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaShopProductComponent);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProductComponents");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
