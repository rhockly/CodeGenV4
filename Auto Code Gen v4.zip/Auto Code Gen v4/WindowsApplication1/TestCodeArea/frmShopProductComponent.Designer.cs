
    partial class frmShopProductComponent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.udcComboForUIBaseProductId = new udcComboForUI();
		this.lblWeightUsed = new System.Windows.Forms.Label();
		this.lblUnitsUsed = new System.Windows.Forms.Label();
		this.txtUnitsUsed = new System.Windows.Forms.TextBox();
		this.txtWeightUsed = new System.Windows.Forms.TextBox();
		this.udcComboForUIShopProductId = new udcComboForUI();
		this.lblShopProductId = new System.Windows.Forms.Label();
		this.lblBaseProductId = new System.Windows.Forms.Label();

		this.SuspendLayout();
		// 
		// udcComboForUIBaseProductId
		// 
		this.udcComboForUIBaseProductId.Location = new System.Drawing.Point(150, 20);
		this.udcComboForUIBaseProductId.MaxLength = 0;
		this.udcComboForUIBaseProductId.Name = "udcComboForUIBaseProductId";
		this.udcComboForUIBaseProductId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUIBaseProductId.TabIndex = 1;
		this.udcComboForUIBaseProductId.SelectedValueChanged += new System.EventHandler(this.udcComboForUIBaseProductId_SelectedValueChanged);		// 
		// lblWeightUsed
		// 
		this.lblWeightUsed.AutoSize = true;
		this.lblWeightUsed.Location = new System.Drawing.Point(20, 83);
		this.lblWeightUsed.Name = "lblWeightUsed";
		this.lblWeightUsed.Size = new System.Drawing.Size(100, 20);
		this.lblWeightUsed.Name = "lblWeightUsed";
		this.lblWeightUsed.Text = "Weight Used";
		// 
		// lblUnitsUsed
		// 
		this.lblUnitsUsed.AutoSize = true;
		this.lblUnitsUsed.Location = new System.Drawing.Point(20, 63);
		this.lblUnitsUsed.Name = "lblUnitsUsed";
		this.lblUnitsUsed.Size = new System.Drawing.Size(100, 20);
		this.lblUnitsUsed.Name = "lblUnitsUsed";
		this.lblUnitsUsed.Text = "Units Used";
		// 
		// txtUnitsUsed
		// 
		this.txtUnitsUsed.Location = new System.Drawing.Point(150, 60);
		this.txtUnitsUsed.MaxLength = 0;
		this.txtUnitsUsed.Name = "txtUnitsUsed";
		this.txtUnitsUsed.Size = new System.Drawing.Size(100, 20);
		this.txtUnitsUsed.TabIndex = 3;
		this.txtUnitsUsed.TextChanged += new System.EventHandler(this.txtUnitsUsed_TextChanged);		// 
		// txtWeightUsed
		// 
		this.txtWeightUsed.Location = new System.Drawing.Point(150, 80);
		this.txtWeightUsed.MaxLength = 0;
		this.txtWeightUsed.Name = "txtWeightUsed";
		this.txtWeightUsed.Size = new System.Drawing.Size(100, 20);
		this.txtWeightUsed.TabIndex = 4;
		this.txtWeightUsed.TextChanged += new System.EventHandler(this.txtWeightUsed_TextChanged);		// 
		// udcComboForUIShopProductId
		// 
		this.udcComboForUIShopProductId.Location = new System.Drawing.Point(150, 40);
		this.udcComboForUIShopProductId.MaxLength = 0;
		this.udcComboForUIShopProductId.Name = "udcComboForUIShopProductId";
		this.udcComboForUIShopProductId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUIShopProductId.TabIndex = 2;
		this.udcComboForUIShopProductId.SelectedValueChanged += new System.EventHandler(this.udcComboForUIShopProductId_SelectedValueChanged);		// 
		// lblShopProductId
		// 
		this.lblShopProductId.AutoSize = true;
		this.lblShopProductId.Location = new System.Drawing.Point(20, 43);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Size = new System.Drawing.Size(100, 20);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Text = "Shop Product";
		// 
		// lblBaseProductId
		// 
		this.lblBaseProductId.AutoSize = true;
		this.lblBaseProductId.Location = new System.Drawing.Point(20, 23);
		this.lblBaseProductId.Name = "lblBaseProductId";
		this.lblBaseProductId.Size = new System.Drawing.Size(100, 20);
		this.lblBaseProductId.Name = "lblBaseProductId";
		this.lblBaseProductId.Text = "Base Product";

            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmShopProductComponent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.udcComboForUIBaseProductId);
this.Controls.Add(this.lblWeightUsed);
this.Controls.Add(this.lblUnitsUsed);
this.Controls.Add(this.txtUnitsUsed);
this.Controls.Add(this.txtWeightUsed);
this.Controls.Add(this.udcComboForUIShopProductId);
this.Controls.Add(this.lblShopProductId);
this.Controls.Add(this.lblBaseProductId);
this.Name = "frmShopProductComponent";
            this.Text = "ShopProductComponent";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private udcComboForUI udcComboForUIBaseProductId;
	private System.Windows.Forms.Label lblWeightUsed;
	private System.Windows.Forms.Label lblUnitsUsed;
	private System.Windows.Forms.TextBox txtUnitsUsed;
	private System.Windows.Forms.TextBox txtWeightUsed;
	private udcComboForUI udcComboForUIShopProductId;
	private System.Windows.Forms.Label lblShopProductId;
	private System.Windows.Forms.Label lblBaseProductId;
}