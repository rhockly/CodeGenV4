using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmBaseProduct
{
    private int _id = 0;
    private daBaseProduct _BaseProduct;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;
			udcComboForUISupplierId.ucDisplaySuppliers();

        if (_id != 0)
        {
            _BaseProduct = new daBaseProduct();
            _BaseProduct.Populate(_id);
			txtUnitsInCase.Text = _BaseProduct.UnitsInCase.ToString();
			txtWeightPerUnit.Text = _BaseProduct.WeightPerUnit.ToString();
			txtName.Text = _BaseProduct.Name.ToString();
			txtPricePerCase.Text = _BaseProduct.PricePerCase.ToString();
			udcComboForUISupplierId.ucSetId(_BaseProduct.SupplierId.ToString());

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _BaseProduct = new daBaseProduct();
            _BaseProduct.Ts = DateTime.Now;
        }

			_BaseProduct.UnitsInCase = Convert.ToInt32(txtUnitsInCase.Text);
			_BaseProduct.WeightPerUnit = Convert.ToInt32(txtWeightPerUnit.Text);
			_BaseProduct.Name = txtName.Text;
			_BaseProduct.PricePerCase = Convert.ToDecimal(txtPricePerCase.Text);
			_BaseProduct.SupplierId = System.Convert.ToInt32( udcComboForUISupplierId.ucGetId());


        eRes = _BaseProduct.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtUnitsInCase_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtWeightPerUnit_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtPricePerCase_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUISupplierId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

