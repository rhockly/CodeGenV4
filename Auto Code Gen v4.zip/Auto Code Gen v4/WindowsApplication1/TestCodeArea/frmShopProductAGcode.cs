using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmShopProduct
{
    private int _id = 0;
    private daShopProduct _ShopProduct;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;
			udcComboForUIShopProductId.ucDisplayShopProducts();
			udcComboForUIPictureId.ucDisplayPictures();

        if (_id != 0)
        {
            _ShopProduct = new daShopProduct();
            _ShopProduct.Populate(_id);
			txtTotal.Text = _ShopProduct.Total.ToString();
			txtName.Text = _ShopProduct.Name.ToString();
			txtPrice.Text = _ShopProduct.Price.ToString();
			txtVat.Text = _ShopProduct.Vat.ToString();
			udcComboForUIShopProductId.ucSetId(_ShopProduct.ShopProductId.ToString());
			udcComboForUIPictureId.ucSetId(_ShopProduct.PictureId.ToString());

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _ShopProduct = new daShopProduct();
            _ShopProduct.Ts = DateTime.Now;
        }

			_ShopProduct.Total = Convert.ToDecimal(txtTotal.Text);
			_ShopProduct.Name = txtName.Text;
			_ShopProduct.Price = Convert.ToDecimal(txtPrice.Text);
			_ShopProduct.Vat = Convert.ToDecimal(txtVat.Text);
			_ShopProduct.ShopProductId = System.Convert.ToInt32( udcComboForUIShopProductId.ucGetId());
			_ShopProduct.PictureId = System.Convert.ToInt32( udcComboForUIPictureId.ucGetId());


        eRes = _ShopProduct.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtTotal_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtPrice_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtVat_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUIShopProductId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void udcComboForUIPictureId_SelectedValueChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

