
    partial class frmShopProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.lblPictureId = new System.Windows.Forms.Label();
		this.lblPrice = new System.Windows.Forms.Label();
		this.lblTotal = new System.Windows.Forms.Label();
		this.txtTotal = new System.Windows.Forms.TextBox();
		this.txtName = new System.Windows.Forms.TextBox();
		this.lblName = new System.Windows.Forms.Label();
		this.txtPrice = new System.Windows.Forms.TextBox();
		this.lblVat = new System.Windows.Forms.Label();
		this.txtVat = new System.Windows.Forms.TextBox();
		this.udcComboForUIShopProductId = new udcComboForUI();
		this.lblShopProductId = new System.Windows.Forms.Label();
		this.udcComboForUIPictureId = new udcComboForUI();

		this.SuspendLayout();
		// 
		// lblPictureId
		// 
		this.lblPictureId.AutoSize = true;
		this.lblPictureId.Location = new System.Drawing.Point(20, 43);
		this.lblPictureId.Name = "lblPictureId";
		this.lblPictureId.Size = new System.Drawing.Size(100, 20);
		this.lblPictureId.Name = "lblPictureId";
		this.lblPictureId.Text = "Picture";
		// 
		// lblPrice
		// 
		this.lblPrice.AutoSize = true;
		this.lblPrice.Location = new System.Drawing.Point(20, 63);
		this.lblPrice.Name = "lblPrice";
		this.lblPrice.Size = new System.Drawing.Size(100, 20);
		this.lblPrice.Name = "lblPrice";
		this.lblPrice.Text = "Price";
		// 
		// lblTotal
		// 
		this.lblTotal.AutoSize = true;
		this.lblTotal.Location = new System.Drawing.Point(20, 103);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Size = new System.Drawing.Size(100, 20);
		this.lblTotal.Name = "lblTotal";
		this.lblTotal.Text = "Total";
		// 
		// txtTotal
		// 
		this.txtTotal.Location = new System.Drawing.Point(150, 100);
		this.txtTotal.MaxLength = 0;
		this.txtTotal.Name = "txtTotal";
		this.txtTotal.Size = new System.Drawing.Size(100, 20);
		this.txtTotal.TabIndex = 5;
		this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);		// 
		// txtName
		// 
		this.txtName.Location = new System.Drawing.Point(150, 20);
		this.txtName.MaxLength = 255;
		this.txtName.Name = "txtName";
		this.txtName.Size = new System.Drawing.Size(100, 20);
		this.txtName.TabIndex = 1;
		this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);		// 
		// lblName
		// 
		this.lblName.AutoSize = true;
		this.lblName.Location = new System.Drawing.Point(20, 23);
		this.lblName.Name = "lblName";
		this.lblName.Size = new System.Drawing.Size(100, 20);
		this.lblName.Name = "lblName";
		this.lblName.Text = "Name";
		// 
		// txtPrice
		// 
		this.txtPrice.Location = new System.Drawing.Point(150, 60);
		this.txtPrice.MaxLength = 0;
		this.txtPrice.Name = "txtPrice";
		this.txtPrice.Size = new System.Drawing.Size(100, 20);
		this.txtPrice.TabIndex = 3;
		this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);		// 
		// lblVat
		// 
		this.lblVat.AutoSize = true;
		this.lblVat.Location = new System.Drawing.Point(20, 123);
		this.lblVat.Name = "lblVat";
		this.lblVat.Size = new System.Drawing.Size(100, 20);
		this.lblVat.Name = "lblVat";
		this.lblVat.Text = "Vat";
		// 
		// txtVat
		// 
		this.txtVat.Location = new System.Drawing.Point(150, 120);
		this.txtVat.MaxLength = 0;
		this.txtVat.Name = "txtVat";
		this.txtVat.Size = new System.Drawing.Size(100, 20);
		this.txtVat.TabIndex = 6;
		this.txtVat.TextChanged += new System.EventHandler(this.txtVat_TextChanged);		// 
		// udcComboForUIShopProductId
		// 
		this.udcComboForUIShopProductId.Location = new System.Drawing.Point(150, 80);
		this.udcComboForUIShopProductId.MaxLength = 0;
		this.udcComboForUIShopProductId.Name = "udcComboForUIShopProductId";
		this.udcComboForUIShopProductId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUIShopProductId.TabIndex = 4;
		this.udcComboForUIShopProductId.SelectedValueChanged += new System.EventHandler(this.udcComboForUIShopProductId_SelectedValueChanged);		// 
		// lblShopProductId
		// 
		this.lblShopProductId.AutoSize = true;
		this.lblShopProductId.Location = new System.Drawing.Point(20, 83);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Size = new System.Drawing.Size(100, 20);
		this.lblShopProductId.Name = "lblShopProductId";
		this.lblShopProductId.Text = "Shop Product";
		// 
		// udcComboForUIPictureId
		// 
		this.udcComboForUIPictureId.Location = new System.Drawing.Point(150, 40);
		this.udcComboForUIPictureId.MaxLength = 0;
		this.udcComboForUIPictureId.Name = "udcComboForUIPictureId";
		this.udcComboForUIPictureId.Size = new System.Drawing.Size(100, 20);
		this.udcComboForUIPictureId.TabIndex = 2;
		this.udcComboForUIPictureId.SelectedValueChanged += new System.EventHandler(this.udcComboForUIPictureId_SelectedValueChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmShopProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblPictureId);
this.Controls.Add(this.lblPrice);
this.Controls.Add(this.lblTotal);
this.Controls.Add(this.txtTotal);
this.Controls.Add(this.txtName);
this.Controls.Add(this.lblName);
this.Controls.Add(this.txtPrice);
this.Controls.Add(this.lblVat);
this.Controls.Add(this.txtVat);
this.Controls.Add(this.udcComboForUIShopProductId);
this.Controls.Add(this.lblShopProductId);
this.Controls.Add(this.udcComboForUIPictureId);
this.Name = "frmShopProduct";
            this.Text = "ShopProduct";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private System.Windows.Forms.Label lblPictureId;
	private System.Windows.Forms.Label lblPrice;
	private System.Windows.Forms.Label lblTotal;
	private System.Windows.Forms.TextBox txtTotal;
	private System.Windows.Forms.TextBox txtName;
	private System.Windows.Forms.Label lblName;
	private System.Windows.Forms.TextBox txtPrice;
	private System.Windows.Forms.Label lblVat;
	private System.Windows.Forms.TextBox txtVat;
	private udcComboForUI udcComboForUIShopProductId;
	private System.Windows.Forms.Label lblShopProductId;
	private udcComboForUI udcComboForUIPictureId;
}