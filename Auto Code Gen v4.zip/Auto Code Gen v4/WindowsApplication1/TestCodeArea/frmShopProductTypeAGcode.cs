using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmShopProductType
{
    private int _id = 0;
    private daShopProductType _ShopProductType;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;

        if (_id != 0)
        {
            _ShopProductType = new daShopProductType();
            _ShopProductType.Populate(_id);
			txtName.Text = _ShopProductType.Name.ToString();

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _ShopProductType = new daShopProductType();
            _ShopProductType.Ts = DateTime.Now;
        }

			_ShopProductType.Name = txtName.Text;


        eRes = _ShopProductType.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

