using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daBaseProduct 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private int _nIdBaseProduct;
	private string _sName;
	private decimal _dPricePerCase;
	private int _nSupplierId;
	private int _nUnitsInCase;
	private int _nWeightPerUnit;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   IdBaseProduct
    //   Description :   Get/Set property for IdBaseProduct.
    //--------------------------------------------------------------------------
    public int IdBaseProduct
    {
        get
        {
            return _nIdBaseProduct;
        }
        set
        {
            _nIdBaseProduct = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Name
    //   Description :   Get/Set property for Name.
    //--------------------------------------------------------------------------
    public string Name
    {
        get
        {
            return _sName;
        }
        set
        {
            _sName = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   PricePerCase
    //   Description :   Get/Set property for PricePerCase.
    //--------------------------------------------------------------------------
    public decimal PricePerCase
    {
        get
        {
            return _dPricePerCase;
        }
        set
        {
            _dPricePerCase = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   SupplierId
    //   Description :   Get/Set property for SupplierId.
    //--------------------------------------------------------------------------
    public int SupplierId
    {
        get
        {
            return _nSupplierId;
        }
        set
        {
            _nSupplierId = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   UnitsInCase
    //   Description :   Get/Set property for UnitsInCase.
    //--------------------------------------------------------------------------
    public int UnitsInCase
    {
        get
        {
            return _nUnitsInCase;
        }
        set
        {
            _nUnitsInCase = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   WeightPerUnit
    //   Description :   Get/Set property for WeightPerUnit.
    //--------------------------------------------------------------------------
    public int WeightPerUnit
    {
        get
        {
            return _nWeightPerUnit;
        }
        set
        {
            _nWeightPerUnit = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdBaseProduct
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdBaseProduct)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdBaseProduct", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdBaseProduct;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblBaseProduct", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdBaseProduct", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdBaseProduct;
            colParamList.Add(prmID);
            
            //Update Name field
            prmParam = new SqlParameter("@Name", SqlDbType.VarChar, 255);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sName;
            colParamList.Add(prmParam);
            //Update PricePerCase field
            prmParam = new SqlParameter("@PricePerCase", SqlDbType.Decimal);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _dPricePerCase;
            colParamList.Add(prmParam);
            //Update SupplierId field
            prmParam = new SqlParameter("@SupplierId", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nSupplierId;
            colParamList.Add(prmParam);
            //Update UnitsInCase field
            prmParam = new SqlParameter("@UnitsInCase", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nUnitsInCase;
            colParamList.Add(prmParam);
            //Update WeightPerUnit field
            prmParam = new SqlParameter("@WeightPerUnit", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _nWeightPerUnit;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblBaseProduct", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdBaseProduct == 0)
                {
                    //Get the new record Id
                    _nIdBaseProduct = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdBaseProduct", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdBaseProduct;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblBaseProduct", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdBaseProduct"))) 
		{
			_nIdBaseProduct = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdBaseProduct"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Name"))) 
		{
			_sName = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Name"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("PricePerCase"))) 
		{
			_dPricePerCase = prdrDataReader.GetDecimal(prdrDataReader.GetOrdinal("PricePerCase"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("SupplierId"))) 
		{
			_nSupplierId = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("SupplierId"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("UnitsInCase"))) 
		{
			_nUnitsInCase = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("UnitsInCase"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("WeightPerUnit"))) 
		{
			_nWeightPerUnit = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("WeightPerUnit"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daBaseProducts : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daBaseProduct Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daBaseProduct odaBaseProduct;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblBaseProducts");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaBaseProduct = new daBaseProduct();
                odaBaseProduct.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaBaseProduct);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblBaseProducts");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
