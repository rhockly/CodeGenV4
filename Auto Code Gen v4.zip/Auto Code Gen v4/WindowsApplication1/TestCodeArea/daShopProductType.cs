using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using DataObjects;
//using SystemObjects;

public partial class daShopProductType 
{
#region Class Variables

    //--------------------------------------------------------------------------
    // Class level variables.
    //--------------------------------------------------------------------------
	private int _nIdShopProductType;
	private string _sName;

	DateTime _dtTs;

#endregion

#region Class Properties

	//--------------------------------------------------------------------------
    //   Name        :   IdShopProductType
    //   Description :   Get/Set property for IdShopProductType.
    //--------------------------------------------------------------------------
    public int IdShopProductType
    {
        get
        {
            return _nIdShopProductType;
        }
        set
        {
            _nIdShopProductType = value;
        }

    }
   	//--------------------------------------------------------------------------
    //   Name        :   Name
    //   Description :   Get/Set property for Name.
    //--------------------------------------------------------------------------
    public string Name
    {
        get
        {
            return _sName;
        }
        set
        {
            _sName = value;
        }

    }
   
    //--------------------------------------------------------------------------
    //   Name        :   Ts
    //   Description :   Get/Set property for ts.
    //--------------------------------------------------------------------------
    public DateTime Ts 
    {
        get
        {
            return _dtTs;
        }
 
        set
        {
            _dtTs = value;
        }

    }

#endregion

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populates the object on IdShopProductType
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate(int pnIdShopProductType)
    {
        ArrayList colParams = new ArrayList();
        SqlParameter prmParam ;
        SqlDataReader rdrReader ;

        try
        {
            // Add Parameters.
            prmParam = new SqlParameter("@IdShopProductType", SqlDbType.Int);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = pnIdShopProductType;
            colParams.Add(prmParam);

            XDatabase.CreateCommand("sp_ag_get_tblShopProductType", colParams);
            rdrReader = XDatabase.returnDataReader();

            // Unpack current row in reader.
            if (rdrReader.Read())
            {
                UnPackDataReaderRow(ref rdrReader);
                return eSqlreturns.Success;
            }
            else
            {
                return eSqlreturns.RecordNotFound;
            }
        }
      

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();;
        }

    }
    
    //--------------------------------------------------------------------------
    //   Name        :   Save
    //   Description :   Insert/Update record
    //   Author      :   RH
    //--------------------------------------------------------------------------

    public eSqlreturns Save() 
    {
        ArrayList colParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;
        SqlParameter prmParam;

        try
        {
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            colParamList.Add(prmRetCode);
            
            //The record id
            prmID = new SqlParameter("@IdShopProductType", SqlDbType.Int);
            prmID.Direction = ParameterDirection.InputOutput;
            prmID.Value = _nIdShopProductType;
            colParamList.Add(prmID);
            
            //Update Name field
            prmParam = new SqlParameter("@Name", SqlDbType.VarChar, 255);
            prmParam.Direction = ParameterDirection.Input;
            prmParam.Value = _sName;
            colParamList.Add(prmParam);
            ;
            
            
            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.InputOutput;
            prmTimestamp.Value = _dtTs;
            colParamList.Add(prmTimestamp);

            //Run the stored procedure
            XDatabase.CreateCommand("sp_ag_save_tblShopProductType", colParamList);
            XDatabase.ExecuteCommand();

            //Check if operation wasn't successfull
            if ((int)prmRetCode.Value == 0) 
            {
                // Get ID.
                if (_nIdShopProductType == 0)
                {
                    //Get the new record Id
                    _nIdShopProductType = (int) prmID.Value;
                }

                // Update Timestamp.
                _dtTs =Convert.ToDateTime(prmTimestamp.Value);
            }

            // return Status.
            return  (eSqlreturns) prmRetCode.Value;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //--------------------------------------------------------------------------
    //   Name        :   Delete
    //   Description :   Delete record from database.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Delete()
	{
        ArrayList prmParamList = new ArrayList();
        SqlParameter prmRetCode;
        SqlParameter prmTimestamp;
        SqlParameter prmID;

        try
		{
            // Add Parameters.

            //The return sql status
            prmRetCode = new SqlParameter("@ret_code", SqlDbType.Int);
            prmRetCode.Direction = ParameterDirection.Output;
            prmParamList.Add(prmRetCode);

            //The time stamp
            prmTimestamp = new SqlParameter("@ts", SqlDbType.DateTime);
            prmTimestamp.Direction = ParameterDirection.Input;
            prmTimestamp.Value = _dtTs;
            prmParamList.Add(prmTimestamp);

            //The record id
            prmID = new SqlParameter("@IdShopProductType", SqlDbType.Int);
            prmID.Direction = ParameterDirection.Input;
            prmID.Value = _nIdShopProductType;
            prmParamList.Add(prmID);;

            // Create command object
            XDatabase.CreateCommand("sp_ag_delete_tblShopProductType", prmParamList);

            // Execute the query.
            XDatabase.ExecuteCommand();

            return (eSqlreturns) prmRetCode.Value;
        }

        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }

    }

    //-------------------------------------------------------------------------------
    //   Name        :   UnPackDataReaderRow
    //   Description :   Unpacks the data from the reader into the objects variables.
    //   Author      :   RH
    //-------------------------------------------------------------------------------
    public void UnPackDataReaderRow(ref SqlDataReader prdrDataReader) 
    {
				if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("IdShopProductType"))) 
		{
			_nIdShopProductType = prdrDataReader.GetInt32(prdrDataReader.GetOrdinal("IdShopProductType"));
		}	
		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("Name"))) 
		{
			_sName = prdrDataReader.GetString(prdrDataReader.GetOrdinal("Name"));
		}	

		if (!prdrDataReader.IsDBNull(prdrDataReader.GetOrdinal("ts")))
        {
            _dtTs = prdrDataReader.GetDateTime(prdrDataReader.GetOrdinal("ts"));
        }
    }

   
#endregion
}

//using System;
//using System.Data;
//using System.Collections;
//using System.Data.SqlClient;

public partial class daShopProductTypes : ArrayList , System.IDisposable
{

#region Class Methods
    //--------------------------------------------------------------------------
    //   Name        :   Dispose
    //   Description :   Object destuctor to free any class resources.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    void IDisposable.Dispose()
    {
        // Clear up objects in array list.
        this.Clear();
    }

    //--------------------------------------------------------------------------
    //   Name        :   Populate
    //   Description :   Populate a collection of daShopProductType Objects.
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public eSqlreturns Populate()
    {
        daShopProductType odaShopProductType;
        SqlDataReader oDataReader;

        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProductTypes");

            // Fetch and return datatable.
            oDataReader = XDatabase.returnDataReader();

            this.Clear();
            while (oDataReader.Read())
            {
                odaShopProductType = new daShopProductType();
                odaShopProductType.UnPackDataReaderRow(ref oDataReader);
                this.Add(odaShopProductType);
            }

            return eSqlreturns.Success;
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }

    //--------------------------------------------------------------------------
    //   Name        :   PopulateForUiList
    //   Description :   return a datatable for the UI
    //   Author      :   RH
    //--------------------------------------------------------------------------
    public DataTable PopulateForUiList()
    {
        
        try
        {
            // Set up SQL command.
            XDatabase.CreateCommand("sp_ag_get_tblShopProductTypes");

            // Fetch and return datatable.
            return XDatabase.returnDataTable();
        }
        finally
        {
            // Destroy Command and Connection objects.
            XDatabase.KillConnection();
        }
    }
#endregion

}
