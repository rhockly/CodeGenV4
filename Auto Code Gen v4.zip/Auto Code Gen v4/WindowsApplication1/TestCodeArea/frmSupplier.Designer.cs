
    partial class frmSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
           		this.lblName = new System.Windows.Forms.Label();
		this.lblTelephone = new System.Windows.Forms.Label();
		this.txtAddress = new System.Windows.Forms.TextBox();
		this.txtMainContact = new System.Windows.Forms.TextBox();
		this.txtTelephone = new System.Windows.Forms.TextBox();
		this.txtMobile = new System.Windows.Forms.TextBox();
		this.txtName = new System.Windows.Forms.TextBox();
		this.txtFax = new System.Windows.Forms.TextBox();
		this.lblMainContact = new System.Windows.Forms.Label();
		this.lblAddress = new System.Windows.Forms.Label();
		this.lblFax = new System.Windows.Forms.Label();
		this.lblMobile = new System.Windows.Forms.Label();

		this.SuspendLayout();
		// 
		// lblName
		// 
		this.lblName.AutoSize = true;
		this.lblName.Location = new System.Drawing.Point(20, 103);
		this.lblName.Name = "lblName";
		this.lblName.Size = new System.Drawing.Size(100, 20);
		this.lblName.Name = "lblName";
		this.lblName.Text = "Name";
		// 
		// lblTelephone
		// 
		this.lblTelephone.AutoSize = true;
		this.lblTelephone.Location = new System.Drawing.Point(20, 123);
		this.lblTelephone.Name = "lblTelephone";
		this.lblTelephone.Size = new System.Drawing.Size(100, 20);
		this.lblTelephone.Name = "lblTelephone";
		this.lblTelephone.Text = "Telephone";
		// 
		// txtAddress
		// 
		this.txtAddress.Location = new System.Drawing.Point(150, 20);
		this.txtAddress.MaxLength = 50;
		this.txtAddress.Name = "txtAddress";
		this.txtAddress.Size = new System.Drawing.Size(100, 20);
		this.txtAddress.TabIndex = 1;
		this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);		// 
		// txtMainContact
		// 
		this.txtMainContact.Location = new System.Drawing.Point(150, 60);
		this.txtMainContact.MaxLength = 50;
		this.txtMainContact.Name = "txtMainContact";
		this.txtMainContact.Size = new System.Drawing.Size(100, 20);
		this.txtMainContact.TabIndex = 3;
		this.txtMainContact.TextChanged += new System.EventHandler(this.txtMainContact_TextChanged);		// 
		// txtTelephone
		// 
		this.txtTelephone.Location = new System.Drawing.Point(150, 120);
		this.txtTelephone.MaxLength = 50;
		this.txtTelephone.Name = "txtTelephone";
		this.txtTelephone.Size = new System.Drawing.Size(100, 20);
		this.txtTelephone.TabIndex = 6;
		this.txtTelephone.TextChanged += new System.EventHandler(this.txtTelephone_TextChanged);		// 
		// txtMobile
		// 
		this.txtMobile.Location = new System.Drawing.Point(150, 80);
		this.txtMobile.MaxLength = 50;
		this.txtMobile.Name = "txtMobile";
		this.txtMobile.Size = new System.Drawing.Size(100, 20);
		this.txtMobile.TabIndex = 4;
		this.txtMobile.TextChanged += new System.EventHandler(this.txtMobile_TextChanged);		// 
		// txtName
		// 
		this.txtName.Location = new System.Drawing.Point(150, 100);
		this.txtName.MaxLength = 255;
		this.txtName.Name = "txtName";
		this.txtName.Size = new System.Drawing.Size(100, 20);
		this.txtName.TabIndex = 5;
		this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);		// 
		// txtFax
		// 
		this.txtFax.Location = new System.Drawing.Point(150, 40);
		this.txtFax.MaxLength = 50;
		this.txtFax.Name = "txtFax";
		this.txtFax.Size = new System.Drawing.Size(100, 20);
		this.txtFax.TabIndex = 2;
		this.txtFax.TextChanged += new System.EventHandler(this.txtFax_TextChanged);		// 
		// lblMainContact
		// 
		this.lblMainContact.AutoSize = true;
		this.lblMainContact.Location = new System.Drawing.Point(20, 63);
		this.lblMainContact.Name = "lblMainContact";
		this.lblMainContact.Size = new System.Drawing.Size(100, 20);
		this.lblMainContact.Name = "lblMainContact";
		this.lblMainContact.Text = "Main Contact";
		// 
		// lblAddress
		// 
		this.lblAddress.AutoSize = true;
		this.lblAddress.Location = new System.Drawing.Point(20, 23);
		this.lblAddress.Name = "lblAddress";
		this.lblAddress.Size = new System.Drawing.Size(100, 20);
		this.lblAddress.Name = "lblAddress";
		this.lblAddress.Text = "Address";
		// 
		// lblFax
		// 
		this.lblFax.AutoSize = true;
		this.lblFax.Location = new System.Drawing.Point(20, 43);
		this.lblFax.Name = "lblFax";
		this.lblFax.Size = new System.Drawing.Size(100, 20);
		this.lblFax.Name = "lblFax";
		this.lblFax.Text = "Fax";
		// 
		// lblMobile
		// 
		this.lblMobile.AutoSize = true;
		this.lblMobile.Location = new System.Drawing.Point(20, 83);
		this.lblMobile.Name = "lblMobile";
		this.lblMobile.Size = new System.Drawing.Size(100, 20);
		this.lblMobile.Name = "lblMobile";
		this.lblMobile.Text = "Mobile";

            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(242, 264);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(161, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 288);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblName);
this.Controls.Add(this.lblTelephone);
this.Controls.Add(this.txtAddress);
this.Controls.Add(this.txtMainContact);
this.Controls.Add(this.txtTelephone);
this.Controls.Add(this.txtMobile);
this.Controls.Add(this.txtName);
this.Controls.Add(this.txtFax);
this.Controls.Add(this.lblMainContact);
this.Controls.Add(this.lblAddress);
this.Controls.Add(this.lblFax);
this.Controls.Add(this.lblMobile);
this.Name = "frmSupplier";
            this.Text = "Supplier";
this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;



   
	private System.Windows.Forms.Label lblName;
	private System.Windows.Forms.Label lblTelephone;
	private System.Windows.Forms.TextBox txtAddress;
	private System.Windows.Forms.TextBox txtMainContact;
	private System.Windows.Forms.TextBox txtTelephone;
	private System.Windows.Forms.TextBox txtMobile;
	private System.Windows.Forms.TextBox txtName;
	private System.Windows.Forms.TextBox txtFax;
	private System.Windows.Forms.Label lblMainContact;
	private System.Windows.Forms.Label lblAddress;
	private System.Windows.Forms.Label lblFax;
	private System.Windows.Forms.Label lblMobile;
}