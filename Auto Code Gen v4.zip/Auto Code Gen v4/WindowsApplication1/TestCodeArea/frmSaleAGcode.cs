using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

partial class frmSale
{
    private int _id = 0;
    private daSale _Sale;
    private bool _Populating;

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    public void Populate(int Id)
    {
        _Populating = true;
        _id = Id;

        if (_id != 0)
        {
            _Sale = new daSale();
            _Sale.Populate(_id);
			txtVat.Text = _Sale.Vat.ToString();
			txtTotal.Text = _Sale.Total.ToString();
			txtSubTotal.Text = _Sale.SubTotal.ToString();
			txtCashRecieved.Text = _Sale.CashRecieved.ToString();
			txtChangeGiven.Text = _Sale.ChangeGiven.ToString();
			txtTimeOfSale.Text = _Sale.TimeOfSale.ToString();

        }
        _Populating = false;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        eSqlreturns eRes = eSqlreturns.Success;

        if (ValidateControls() != "")
        {
            return;
        }

        if (_id == 0)
        {
            _Sale = new daSale();
            _Sale.Ts = DateTime.Now;
        }

			_Sale.Vat = Convert.ToDecimal(txtVat.Text);
			_Sale.Total = Convert.ToDecimal(txtTotal.Text);
			_Sale.SubTotal = Convert.ToDecimal(txtSubTotal.Text);
			_Sale.CashRecieved = Convert.ToDecimal(txtCashRecieved.Text);
			_Sale.ChangeGiven = Convert.ToDecimal(txtChangeGiven.Text);
			_Sale.TimeOfSale = Convert.ToDateTime(txtTimeOfSale.Text);


        eRes = _Sale.Save();

        UiSupport.DisplayMessage(eRes);
        this.Close();
    }

   
	private void txtVat_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtTotal_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtSubTotal_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtCashRecieved_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtChangeGiven_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}
	private void txtTimeOfSale_TextChanged(object sender, EventArgs e)
	{
		ValidateControls();
	}


}

