using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

   public static class UiSupport
    {

       public static string FormatName(string Name)
       {
           string findUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
           string aChar;
           string aPreviousChar="";
           string NewName = "";

           for (int i = 0; i < Name.Length; i++)
           {
               aChar = Name.Substring(i, 1);
               if (findUpper.IndexOf(aChar) != -1)
               {
                   if (i == 0)
                   {
                       NewName += aChar;
                   }
                   else
                   {
                       if (aPreviousChar != " ")
                       {
                           NewName += " " + aChar;
                       }
                       else
                       {
                           NewName +=  aChar;
                       }
                       
                   }
               }
               else
               {
                   NewName += aChar;
               }
               aPreviousChar = aChar;

           }
           if (NewName.ToLower().EndsWith("id"))
           {
               NewName = NewName.Substring(0, NewName.Length - 2);
               NewName = NewName.Trim();
           }
           return NewName;

       }

       public static bool DisplayMessage(eSqlreturns eMessage)
       {
           bool result = false;

           switch (eMessage)
           {
               case eSqlreturns.Success:
                   result = true;
                   break;
               case eSqlreturns.RecordNotFound:
                   MessageBox.Show("Record Not Found" , "Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                   break;
               case eSqlreturns.RecordAlreadyUpdated:
                   MessageBox.Show("Record Has Already Been Updated By Another User", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                   break;
               case eSqlreturns.RecordNotUpdated:
                   MessageBox.Show("Record Has Not been Updated", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                   break;
               case eSqlreturns.RecordHasChildRecords:
                   MessageBox.Show("The Record Has Child Records" , "Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                   break;
               case eSqlreturns.RecordAlreadyExists:
                   MessageBox.Show("The Record Already Exists", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                   break;
               case eSqlreturns.IncorrectDataEntry:
                   MessageBox.Show("Incorrect Data Enrty", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                   break;
               case eSqlreturns.DeleteSuccessful:
                   MessageBox.Show("Delete Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   break;
               case eSqlreturns.UpdateSuccessful:
                   MessageBox.Show("Update Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   break;
               case eSqlreturns.CreateSuccessful:
                   MessageBox.Show("Create Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   break;
                  
               default:
                   break;
           }
           return result;

       }

    }

