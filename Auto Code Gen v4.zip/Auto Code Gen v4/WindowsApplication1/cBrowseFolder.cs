using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;


namespace RH
{
    public class cBrowseFolder
    {
        // NOTE: requires a reference to the System.Design.Dll assembly
        string m_sDescription;
        string m_sPath;

        public string Description
        {
            get
            {
                return m_sDescription;
            }
            set
            {
                m_sDescription = value;
            }
        }

        public string Path
        {
            get
            {
                return m_sPath;
            }

            set
            {
                m_sPath = value;
            }
        }

        public DialogResult ShowDialog()
        {
            FolderBrowser oFolderBrowser;
            oFolderBrowser = new FolderBrowser(this);
            return oFolderBrowser.ShowDialog();
        }

        private class FolderBrowser : FolderNameEditor
        {
            cBrowseFolder oBrowseForFoldersDialog;

            public FolderBrowser(cBrowseFolder oBrowseForFoldersDialog)
            {
                this.oBrowseForFoldersDialog = oBrowseForFoldersDialog;
            }

            public DialogResult ShowDialog()
            {
                //System.Windows.Forms.DialogResult
                System.Windows.Forms.DialogResult ShowDialogResult;
                FolderNameEditor.FolderBrowser oFolderBrowser = new FolderNameEditor.FolderBrowser();

                oFolderBrowser.Description = oBrowseForFoldersDialog.m_sDescription;
                ShowDialogResult = oFolderBrowser.ShowDialog();
                if (ShowDialogResult == DialogResult.OK)
                {
                    oBrowseForFoldersDialog.m_sPath = oFolderBrowser.DirectoryPath;
                }
                return ShowDialogResult;
            }
        }
    }
}
