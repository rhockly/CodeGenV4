namespace RH
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTemplateFolder = new System.Windows.Forms.TextBox();
            this.txtOutputFolder = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnFindTemplates = new System.Windows.Forms.Button();
            this.btnFindOutputFolder = new System.Windows.Forms.Button();
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.btnGetDbStructure = new System.Windows.Forms.Button();
            this.tablesTree = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.txtClassNamePrefix = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFormNamePrefix = new System.Windows.Forms.TextBox();
            this.btnMake = new System.Windows.Forms.Button();
            this.btnShowEntity = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Template Folder:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Output Folder:";
            // 
            // txtTemplateFolder
            // 
            this.txtTemplateFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTemplateFolder.BackColor = System.Drawing.SystemColors.Control;
            this.txtTemplateFolder.Location = new System.Drawing.Point(95, 0);
            this.txtTemplateFolder.Name = "txtTemplateFolder";
            this.txtTemplateFolder.Size = new System.Drawing.Size(225, 20);
            this.txtTemplateFolder.TabIndex = 7;
            // 
            // txtOutputFolder
            // 
            this.txtOutputFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutputFolder.BackColor = System.Drawing.SystemColors.Control;
            this.txtOutputFolder.Location = new System.Drawing.Point(95, 26);
            this.txtOutputFolder.Name = "txtOutputFolder";
            this.txtOutputFolder.Size = new System.Drawing.Size(225, 20);
            this.txtOutputFolder.TabIndex = 8;
            // 
            // btnFindTemplates
            // 
            this.btnFindTemplates.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFindTemplates.Location = new System.Drawing.Point(326, 0);
            this.btnFindTemplates.Name = "btnFindTemplates";
            this.btnFindTemplates.Size = new System.Drawing.Size(27, 23);
            this.btnFindTemplates.TabIndex = 13;
            this.btnFindTemplates.Text = ">>";
            this.btnFindTemplates.UseVisualStyleBackColor = true;
            this.btnFindTemplates.Click += new System.EventHandler(this.btnFindTemplates_Click);
            // 
            // btnFindOutputFolder
            // 
            this.btnFindOutputFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFindOutputFolder.Location = new System.Drawing.Point(326, 24);
            this.btnFindOutputFolder.Name = "btnFindOutputFolder";
            this.btnFindOutputFolder.Size = new System.Drawing.Size(27, 23);
            this.btnFindOutputFolder.TabIndex = 14;
            this.btnFindOutputFolder.Text = ">>";
            this.btnFindOutputFolder.UseVisualStyleBackColor = true;
            this.btnFindOutputFolder.Click += new System.EventHandler(this.btnFindOutputFolder_Click);
            // 
            // btnGetDbStructure
            // 
            this.btnGetDbStructure.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetDbStructure.Location = new System.Drawing.Point(327, 371);
            this.btnGetDbStructure.Name = "btnGetDbStructure";
            this.btnGetDbStructure.Size = new System.Drawing.Size(102, 28);
            this.btnGetDbStructure.TabIndex = 30;
            this.btnGetDbStructure.Text = "&Get Db Structure";
            this.btnGetDbStructure.UseVisualStyleBackColor = true;
            this.btnGetDbStructure.Click += new System.EventHandler(this.btnGetDbStructure_Click);
            // 
            // tablesTree
            // 
            this.tablesTree.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tablesTree.ImageIndex = 0;
            this.tablesTree.ImageList = this.imageList1;
            this.tablesTree.Location = new System.Drawing.Point(12, 104);
            this.tablesTree.Name = "tablesTree";
            this.tablesTree.SelectedImageIndex = 0;
            this.tablesTree.Size = new System.Drawing.Size(308, 339);
            this.tablesTree.TabIndex = 31;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "BlankImg.bmp");
            this.imageList1.Images.SetKeyName(1, "IdImg.bmp");
            this.imageList1.Images.SetKeyName(2, "TsImg.bmp");
            this.imageList1.Images.SetKeyName(3, "BlankSelImg.bmp");
            this.imageList1.Images.SetKeyName(4, "IdSelImg.bmp");
            this.imageList1.Images.SetKeyName(5, "TsSelImg.bmp");
            this.imageList1.Images.SetKeyName(6, "FkImg.bmp");
            this.imageList1.Images.SetKeyName(7, "FkSelImg.bmp");
            // 
            // txtClassNamePrefix
            // 
            this.txtClassNamePrefix.Location = new System.Drawing.Point(223, 52);
            this.txtClassNamePrefix.Name = "txtClassNamePrefix";
            this.txtClassNamePrefix.Size = new System.Drawing.Size(95, 20);
            this.txtClassNamePrefix.TabIndex = 37;
            this.txtClassNamePrefix.TextChanged += new System.EventHandler(this.txtClassNamePrefix_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "C# Class Name Prefix:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 39;
            this.label4.Text = "Form Name Prefix:";
            // 
            // txtFormNamePrefix
            // 
            this.txtFormNamePrefix.Location = new System.Drawing.Point(223, 78);
            this.txtFormNamePrefix.Name = "txtFormNamePrefix";
            this.txtFormNamePrefix.Size = new System.Drawing.Size(95, 20);
            this.txtFormNamePrefix.TabIndex = 40;
            this.txtFormNamePrefix.TextChanged += new System.EventHandler(this.txtFormNamePrefix_TextChanged);
            // 
            // btnMake
            // 
            this.btnMake.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMake.Enabled = false;
            this.btnMake.Location = new System.Drawing.Point(326, 405);
            this.btnMake.Name = "btnMake";
            this.btnMake.Size = new System.Drawing.Size(102, 28);
            this.btnMake.TabIndex = 41;
            this.btnMake.Text = "&Make";
            this.btnMake.UseVisualStyleBackColor = true;
            this.btnMake.Click += new System.EventHandler(this.btnMake_Click);
            // 
            // btnShowEntity
            // 
            this.btnShowEntity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnShowEntity.Location = new System.Drawing.Point(327, 164);
            this.btnShowEntity.Name = "btnShowEntity";
            this.btnShowEntity.Size = new System.Drawing.Size(102, 28);
            this.btnShowEntity.TabIndex = 42;
            this.btnShowEntity.Text = "&Show Entity";
            this.btnShowEntity.UseVisualStyleBackColor = true;
            this.btnShowEntity.Click += new System.EventHandler(this.btnShowEntity_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(329, 138);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 20);
            this.txtId.TabIndex = 43;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 445);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.btnShowEntity);
            this.Controls.Add(this.btnMake);
            this.Controls.Add(this.txtFormNamePrefix);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtClassNamePrefix);
            this.Controls.Add(this.tablesTree);
            this.Controls.Add(this.btnGetDbStructure);
            this.Controls.Add(this.btnFindOutputFolder);
            this.Controls.Add(this.btnFindTemplates);
            this.Controls.Add(this.txtOutputFolder);
            this.Controls.Add(this.txtTemplateFolder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Class Generator V4";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTemplateFolder;
        private System.Windows.Forms.TextBox txtOutputFolder;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnFindTemplates;
        private System.Windows.Forms.Button btnFindOutputFolder;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.Button btnGetDbStructure;
        private System.Windows.Forms.TreeView tablesTree;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txtClassNamePrefix;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFormNamePrefix;
        private System.Windows.Forms.Button btnMake;
        private System.Windows.Forms.Button btnShowEntity;
        private System.Windows.Forms.TextBox txtId;
    }
}